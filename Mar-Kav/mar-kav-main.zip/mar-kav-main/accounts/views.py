from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout

# Create your views here.
################################
def login_view(request):

    need_redirect = request.GET.get('next')

    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username = username, password = password)

        if user is None:
            view_context = {
                'error': 'שם משתמש או סיסמה אינם נכונים!'
            }
            return render(request, 'apps/login.html', context=view_context)

        # user is not none!!!
        login(request, user)
        return redirect('/')

    view_context = {
        'need_redirect' : need_redirect
    }
    return render(request, 'apps/login.html', context=view_context)

##################################
def logout_view(request):

    if request.method == 'POST':
        logout(request)
        return redirect('/login')

    return render(request, 'apps/logout.html', {})

################################
def register_view(request):

    return render(request, 'apps/empty.html', {})


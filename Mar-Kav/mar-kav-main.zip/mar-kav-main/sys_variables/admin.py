from django.contrib import admin

# Register your models here.
from .models import Sys_Variables

class Sys_VariablesAdmin(admin.ModelAdmin):
    list_display = ['sys_key', 'sys_value']
    search_fields = ['sys_key', 'sys_value']

admin.site.register(Sys_Variables, Sys_VariablesAdmin)

from django.apps import AppConfig


class SysVariablesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sys_variables'

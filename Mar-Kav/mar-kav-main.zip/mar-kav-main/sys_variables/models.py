from django.db import models

# Create your models here.
class Sys_Variables(models.Model):

    sys_key = models.CharField(db_index=True, max_length=20)
    sys_value = models.CharField(max_length=1000)

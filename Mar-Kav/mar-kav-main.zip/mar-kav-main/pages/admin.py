from django.contrib import admin

# Register your models here.
from .models import Page

class PageAdmin(admin.ModelAdmin):
    list_display = ['Title', 'id', 'Date']
    search_fields = ['Date', 'Title']

admin.site.register(Page, PageAdmin)
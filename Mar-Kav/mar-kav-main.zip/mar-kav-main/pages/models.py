from django.db import models

# Create your models here.
class Page(models.Model):

    Title = models.CharField(max_length=150, null=True, blank=True)
    Content = models.TextField()
    Date = models.DateTimeField(auto_now_add=True, blank=True)
from django.shortcuts import render

# Create your views here.
from .models import Page

def page_detail_view(request, id=None):

    page_obj = None
    debug_message = None

    # try to load
    if id is not None:
        try:
            page_obj = Page.objects.get(id=id)
        except Page.DoesNotExist:
            page_obj = None
            debug_message = 'Page.DoesNotExist'
    else:
        debug_message = 'No id'

    # save to context
    view_context = {
        'page_data': page_obj,
        'debug_message' : debug_message,
    }

    return render(request, 'apps/page_detail.html', context=view_context)
from django.contrib import admin

# Register your models here.
from .models import Shape

class ShapeAdmin(admin.ModelAdmin):
    list_display = ['Route_Full_Id', 'Route_Line_Id']
    search_fields = ['Route_Full_Id', 'Route_Line_Id']

admin.site.register(Shape, ShapeAdmin)
from django.db import models

# Create your models here.
class Shape(models.Model):
    Route_Full_Id = models.CharField(db_index=True, max_length=12)
    Route_LineDirection_Id = models.CharField(max_length=10)
    Route_Line_Id = models.CharField(max_length=6)
    route_points = models.TextField() # המסלול של חלופה זו
from django.shortcuts import render
from django.http import JsonResponse
import pandas as pd

# Create your views here.
from .models import Shape
# Create your views here.
from stations_ridership.models import StationRidership

def shapes_geojson_view(request):

    q_dict = request.GET
    debug_message = ''
    DisplayType = 'All'

    try:
        Route_Full_Ids = q_dict.get('q',None)
        DisplayType = q_dict.get('d','All')
    except:
        debug_message += 'חיפוש לא חוקי'
        Route_Full_Ids = None

    shape_objs = None

    # try to load
    if Route_Full_Ids is not None:
        try:
            print(Route_Full_Ids)
            Route_Full_Id_list = list(Route_Full_Ids.split(","))

            shape_objs = Shape.objects.filter(Route_Full_Id__in=Route_Full_Id_list)

        except Shape.DoesNotExist:
            shape_objs = None
            debug_message += 'Shape.DoesNotExist'
    else:
        debug_message += 'No Route_Id'

    if shape_objs == None:
        debug_message += 'No Route_Full_Ids Found'

#################################################
    SR_objs = None
    SR_dataframe = pd.DataFrame()

    # try to load
    if Route_Full_Ids is not None:
        try:

            Route_Full_Id_list = list(Route_Full_Ids.split(","))
            SR_objs = StationRidership.objects.filter(Route_Full_Id__in=Route_Full_Id_list).order_by('Route_Full_Id','Stop_line_order')

        except StationRidership.DoesNotExist:
            SR_objs = None
            debug_message += 'StationRidership.DoesNotExist'

        if DisplayType == 'Origin':
            SR_objs = SR_objs.filter(Stop_line_order=1)

        if SR_objs is not None:
            SR_dataframe = pd.DataFrame.from_records(SR_objs.values())

            if SR_dataframe.Route_Full_Id.nunique() > 1:
                PivData = SR_dataframe.pivot_table(index=['Stop_ID', 'Stop_name', 'Lat', 'Long'],
                                            # columns=['name'],
                                            values=['Week'],
                                            aggfunc=sum)

                SR_dataframe = pd.DataFrame(PivData.to_records())

                # SR_dataframe.sort_values('Week', axis=0, ascending=False, inplace=True, na_position='last')
                #
                # SR_dataframe = SR_dataframe.iloc[0:3]
            SR_dataframe['Size'] = 6
            if DisplayType != 'Origin':
                SR_dataframe['Size'] = round(5 + 10 * SR_dataframe['Week'] / SR_dataframe['Week'].max(), 0)
            SR_dataframe['Week'] = round(SR_dataframe['Week'], 1)
            SR_dataframe['Stop_name'] = SR_dataframe['Stop_name'].str.replace(r'\\', '-', regex=True)
            SR_dataframe['Stop_name'] = SR_dataframe['Stop_name'].str.replace('"', '\"', regex=True)

    if SR_dataframe.empty:
        debug_message += 'No Route_LineDirection_Id Found'

    print('debug_message',debug_message)


    # save to context
    view_context = {
        'shape_objs': shape_objs,
        'stations_objs': SR_dataframe,
        'debug_message' : debug_message,
    }

    # return JsonResponse({'foo':'bar'})

    # return render(request, 'apps/shapes_geojson.geojson', context=view_context)

    response = render(request, 'apps/shapes_geojson.geojson', context=view_context)
    response['X-Robots-Tag'] = 'noindex'
    return response


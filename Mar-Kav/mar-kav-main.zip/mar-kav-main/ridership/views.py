from django.shortcuts import render
from django.contrib.auth.decorators import login_required, user_passes_test
from django.views.decorators.clickjacking import xframe_options_exempt

# Create your views here.
from lines.models import Line, Line_Direction
from shapes.models import Shape
from time_series.models import TimeSeries
from comments.models import Comment
from stations_ridership.models import StationRidership
from graphs_data.models import GraphData

from sys_variables.models import Sys_Variables

# import time
from datetime import datetime

from .models import Ridership

def is_Planner(user):
    ret_val = False

    if user.is_authenticated:
        ret_val = user.email.endswith('@adalya.co.il')
        ret_val = ret_val or user.groups.filter(name='Planner').exists()

    return ret_val

# @login_required
#  @user_passes_test(is_Planner)
@xframe_options_exempt
def ridership_detail_view(request, Route_Id=None):

    line_obj = None
    debug_message = None
    shape_objs = None
    ts_objs_dict = None
    comments_obj = None
    overlay_message = ''


    LAST_UPDATE = getattr(Sys_Variables.objects.get(sys_key='LAST_UPDATE'), 'sys_value')
    LAST_UPDATE = datetime.strptime(LAST_UPDATE, "%d-%m-%Y").date()

    # try to load
    if Route_Id is not None:
        try:
            print(Route_Id)
            line_obj = Line.objects.get(Route_Id=Route_Id)
            shape_objs = Shape.objects.filter(Route_Line_Id=Route_Id)

            ts_objs = TimeSeries.objects.filter(Index_Id__startswith=Route_Id)

            ### if is_Planner(request.user):
            comments_obj = Comment.objects.filter(Route_Id=Route_Id).order_by('-date')


            #StationRidershipCount = StationRidership.objects.filter(Route_LineDirection_Id=ldirection.Route_LineDirection_Id).count() * 20
            StationRidership_objs = StationRidership.objects.filter(Route_Id=Route_Id).values('Route_Full_Id').distinct()



            Line_LAST_UPDATE = getattr(line_obj, 'Line_updated_on')

            delta = LAST_UPDATE - Line_LAST_UPDATE
            if delta.days > 10:
                overlay_message = 'שים לב! קו זה אינו מציג מידע מעודכן אלא מידע מתאריך ' + str(Line_LAST_UPDATE)

            ts_objs_dict={}
            for ts_o in ts_objs.iterator():
                ts_objs_dict[ts_o.Section] = ts_o.get_Section_display()


        except Line.DoesNotExist:
            line_obj = None
            debug_message = 'Line.DoesNotExist'
    else:
        debug_message = 'No Route_Id'

    if line_obj == None:
        debug_message = 'No Route Found'


    # save to context
    view_context = {
        'overlay_message' : overlay_message,
        'line': line_obj,
        'shape_objs': shape_objs,
        'TimeSeries_objs': ts_objs_dict,
        'comments': comments_obj,
        'StationRidership_objs': StationRidership_objs,
        'debug_message' : debug_message,
    }

    return render(request, 'apps/line_ridership_detail.html', context=view_context)


@xframe_options_exempt
def lineDirection_view(request, Route_Id=None, Direction=None):

    line_obj = None
    lineDir_obj = None
    debug_message = None
    shape_objs = None
    timeTable_obj = None
    # comments_obj = None
    # StationRidership_objs = None
    overlay_message = ''

    LAST_UPDATE = getattr(Sys_Variables.objects.get(sys_key='LAST_UPDATE'), 'sys_value')
    LAST_UPDATE = datetime.strptime(LAST_UPDATE, "%d-%m-%Y").date()

    Route_LineDirection_Id = str(Route_Id) + '-' + str(Direction)

    # try to load
    if len(Route_LineDirection_Id) == 7:
        try:
            print('Route_Id, Direction', Route_Id, Direction)

            line_obj = Line.objects.get(Route_Id=Route_Id)
            lineDir_obj = Line_Direction.objects.get(Route_LineDirection_Id = Route_LineDirection_Id)
            GraphData_obj = GraphData.objects.filter(Index_Id = Route_LineDirection_Id)

            shape_objs = Shape.objects.filter(Route_LineDirection_Id=Route_LineDirection_Id)

            Line_LAST_UPDATE = getattr(line_obj, 'Line_updated_on')

            delta = LAST_UPDATE - Line_LAST_UPDATE
            if delta.days > 10:
                overlay_message = 'שים לב! קו זה אינו מציג מידע מעודכן אלא מידע מתאריך ' + str(Line_LAST_UPDATE)

            timeTable_obj = GraphData_obj.filter(Type = 'RR')
            # This is to pass the names
            tT_objs_dict={}
            for ts_o in timeTable_obj.iterator():
                tT_objs_dict[ts_o.Section] = ts_o.get_Section_display()

            Profiles_obj = GraphData_obj.filter(Type = 'LP')

        except Line.DoesNotExist:
            line_obj = None
            debug_message = 'Line.DoesNotExist'
    else:
        debug_message = 'No valid LineDirection_Id'

    if line_obj == None:
        debug_message = 'No Route Found'

    # save to context
    view_context = {
        'overlay_message' : overlay_message,
        'line': line_obj,
        'Line_Dir' :lineDir_obj,
        'direction': Direction,
        'shape_objs': shape_objs,
        'timeTable_obj' : timeTable_obj,
        'tT_objs_dict': tT_objs_dict,
        'LP_objs_dict': Profiles_obj,
        'debug_message' : debug_message,
    }

    return render(request, 'apps/line_direction_detail.html', context=view_context)
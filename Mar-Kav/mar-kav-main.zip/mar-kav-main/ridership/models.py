from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator
from lines.models import Line_Direction

# Create your models here.
class Ridership(models.Model):

    p_Line_direction = models.ForeignKey(Line_Direction, on_delete=models.CASCADE, related_name='line_direction_ridership')

    Route_LineDirection_Id = models.CharField(max_length=10, default=None) # מקט - כיוון
    Route_Id = models.PositiveIntegerField(validators=[MinValueValidator(10000),
                                                         MaxValueValidator(100000)], default=None) # מק"ט

    Avg_riders_per_KM = models.FloatField(validators=[MinValueValidator(0),
                                    MaxValueValidator(10000)]) # ממוצע נוסעים לקילומטר
    Stop_Count = models.PositiveIntegerField(validators=[MinValueValidator(1),
                                    MaxValueValidator(250)]) # מספר תחנות בקו
    Singular_Stops = models.TextField(default=None,blank=True,null=True) # תחנות שקו זה משרת בבלעדיות
    Singular_Settlement = models.CharField(max_length=250, default=None,blank=True,null=True) # ישובים שקו זה משרת בבלעדיות


    Daily_riders = models.PositiveIntegerField(validators=[MinValueValidator(0),
                                     MaxValueValidator(10000)]) # נוסעים יומי
    Weekly_riders = models.PositiveIntegerField(validators=[MinValueValidator(0),
                                     MaxValueValidator(100000)]) # נוסעים שבועי
    Avg_riders_per_ride = models.FloatField(validators=[MinValueValidator(0),
                                     MaxValueValidator(1000)]) # ממוצע נוסעים לנסיעה (שבועי)

    recomandation = models.TextField(default=None,blank=True,null=True)  # המלצה
    Max_per_time_period = models.FloatField(default=None,blank=True,null=True, validators=[MinValueValidator(0),
                                     MaxValueValidator(1000)])  # ערך מקסימום בתקופת יום
    Shift_ranking = models.IntegerField(default=None,blank=True,null=True) # דרוג תיעדוף הסטות
    Comment = models.TextField(default=None,blank=True,null=True)  # הערה
    Last_update = models.DateField()  # עדכון אחרון

from django.shortcuts import render, HttpResponseRedirect
from django.views.decorators.clickjacking import xframe_options_exempt
from django.db.models.functions import Cast
from django.db.models import IntegerField

from shapes.models import Shape
from stations_ridership.models import StationRidership
from sys_variables.models import Sys_Variables
# import time
from datetime import datetime, timedelta
import codecs
import csv
from django.http import HttpResponse
import json

# Create your views here.
from .models import Line

def lines_serch_view(request):

    q_dict = request.GET
    debug_message = ''
    q_Line_Name = None

    try:
        q_Line_Name = q_dict.get('q')
    except:
        debug_message = 'חיפוש לא חוקי'

    line_objs = None
    stop_obj = None
    words_list=[]

    if q_Line_Name is not None:
        words_list = q_Line_Name.split()

        # חיפוש תחנה ישיר על פי מקט
        if 'תחנה' in words_list:
            words_list.remove('תחנה')

            if len(words_list) == 1:
                item = words_list[0]

                if item.isnumeric():
                    q_stop_Num = int(words_list[0])

                    try:
                        stop_obj = StationRidership.objects.filter(Stop_ID=q_stop_Num).first()

                    except StationRidership.DoesNotExist:
                        stop_obj = None
                        debug_message = 'StationRidership.DoesNotExist'

                    if stop_obj != None:
                        print(stop_obj)
                        print('redirect here:    /stop/' + str(stop_obj.Stop_ID))
                        return HttpResponseRedirect('/stop/' + str(stop_obj.Stop_ID))

        else:
            if 'קו' in words_list:
                words_list.remove('קו')

            words_list2 = words_list

            if len(words_list) > 0:
                line_objs = Line.objects.all()

                for item in words_list:

                    if item.isnumeric():

                        q_Line_Num = int(item)

                        if q_Line_Num < 1000:
                            line_objs = line_objs.filter(Line_Name = q_Line_Num)
                            words_list2.remove(item)

                        elif (q_Line_Num > 10000) and (q_Line_Num < 100000):
                            line_objs = line_objs.filter(Route_Id=q_Line_Num)
                            words_list2.remove(item)


                for q_word in words_list2:
                    line_objs = line_objs.filter(Line_full_name__contains=q_word)

    if line_objs == None:
        debug_message = 'לא נמצאו תוצאות תואמות'

        if len(words_list) == 0:
            debug_message = 'חיפוש לא ממוקד, נא חפש על פי עיר או מספר קו'


    # נמצא רק קו אחד, במקום להציג רשימה, הכנס ישירות לדף הרצוי
    elif len(line_objs) == 1:
        print('redirect here:    /line/' + str(line_objs[0].Route_Id))
        return HttpResponseRedirect('/line/' + str(line_objs[0].Route_Id))

    # אל תכלול ברשימה קווים שאינם מעודכנים אם לא נגשו אליהם ישירות
    LAST_UPDATE = getattr(Sys_Variables.objects.get(sys_key='LAST_UPDATE'), 'sys_value')
    LAST_UPDATE = datetime.strptime(LAST_UPDATE, "%d-%m-%Y").date() - timedelta(days = 10)

    line_objs = line_objs.filter(Line_updated_on__gt = LAST_UPDATE)

    # לאחר הסינון בדוק שוב כמה קווים יש לנו
    if line_objs == None:
        debug_message = 'לא נמצאו תוצאות תואמות'

        if len(words_list) == 0:
            debug_message = 'חיפוש לא ממוקד, נא חפש על פי עיר או מספר קו'

    # נמצא רק קו אחד, במקום להציג רשימה, הכנס ישירות לדף הרצוי
    elif len(line_objs) == 1:
        print('redirect here:    /line/' + str(line_objs[0].Route_Id))
        return HttpResponseRedirect('/line/' + str(line_objs[0].Route_Id))

    # sort
    line_objs = line_objs.annotate(Line_Name_integer=Cast('Line_Name', output_field=IntegerField())).order_by('Line_Name_integer').values()


    # save to context
    view_context = {
        'title': 'תוצאות חיפוש - קו ' + str(q_Line_Name),
        'line_list': line_objs,
        'debug_message' : debug_message,
    }

    return render(request, 'apps/lines_serch.html', context=view_context)

######################################################################
def line_sitemap_view(request):

    line_objs = Line.objects.all()

    # save to context
    view_context = {
        'line_list': line_objs,
    }

    return render(request, 'apps/sitemap.xml', context=view_context)

######################################################################
def line_list_view(request):

    line_objs = Line.objects.all().order_by('Cluster_Name')

    debug_message = ''

    # save to context
    view_context = {
        'line_list': line_objs,
        'debug_message' : debug_message,
    }

    return render(request, 'apps/lines.html', context=view_context)

def LineRidershipHistory_csvDownload_view(request):
    # Line_RidershipHistory

    q_dict = request.GET
    line_Id = q_dict.get('q')

    line_obj = None
    debug_message = None
    data=None

    print('line_Id' + str(line_Id))

    # try to load
    if line_Id is not None:
        try:
            line_obj = Line.objects.get(Route_Id=line_Id)
            data = json.loads(line_obj.Line_RidershipHistory)
        except Line.DoesNotExist:
            line_obj = None
            debug_message = 'Line.DoesNotExist'
    else:
        debug_message = 'No id'


    filename = 'LineRidershipHistory_' + line_Id + '.csv'

    # http://127.0.0.1:8000/RidershipHistoryDL?q=12125

    # Create the HttpResponse object with the appropriate CSV header.
    response = HttpResponse(
        content_type='text/csv',
        headers={'Content-Disposition': 'attachment; filename="' + filename +'"'},
    )

    response.write(codecs.BOM_UTF8)

    writer = csv.DictWriter(response, fieldnames=data.keys())
    writer.writeheader()
    writer.writerow(data)

    return response


######################################################################
@xframe_options_exempt
def line_map_view(request, Route_Id=None):

    line_obj = None
    debug_message = None
    shape_obj = None

    # try to load
    if Route_Id is not None:
        try:
            print(Route_Id)
            line_obj = Line.objects.get(Route_Id=Route_Id)
            shape_objs = Shape.objects.filter(Route_Line_Id=Route_Id)

        except Line.DoesNotExist:
            line_obj = None
            debug_message = 'Line.DoesNotExist'
    else:
        debug_message = 'No Route_Id'

    if line_obj == None:
        debug_message = 'No Route Found'

    # save to context
    view_context = {
        'line': line_obj,
        'shape_objs': shape_objs,
        'debug_message' : debug_message,
    }

    return render(request, 'apps/line_map_detail.html', context=view_context)
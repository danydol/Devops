from django.contrib import admin

# Register your models here.
from .models import Line, Line_Direction

class LineAdmin(admin.ModelAdmin):
    list_display = ['Route_Id', 'Line_full_name']
    search_fields = ['Route_Id', 'Line_full_name']

admin.site.register(Line, LineAdmin)

class Line_DirectionAdmin(admin.ModelAdmin):
    list_display = ['Route_Id', 'Route_LineDirection_Id']
    search_fields = ['Route_Id', 'Route_LineDirection_Id']

admin.site.register(Line_Direction, Line_DirectionAdmin)
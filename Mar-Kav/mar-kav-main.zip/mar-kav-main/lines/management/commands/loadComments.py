from django.core.management.base import BaseCommand, CommandError
from comments.models import Comment
from django.contrib.auth.models import User
import datetime

import pandas as pd
# import numpy as np
import os
from django.utils import timezone

class Command(BaseCommand):
    help = "Loads comments data"

    def add_arguments(self, parser):
        parser.add_argument("file_path", type=str)

    def handle(self, *args, **options):

        # First - delete previous data
        # NO DELETE IN THIS CASE !!!

        # now load
        print('loading data')

        start_time = timezone.now()
        loadPack = 0

        file_path = options["file_path"]

        data = pd.read_csv(file_path)

        print('Preparing the file')

        if 'Route_Full_Id' not in data:
            data['Route_Full_Id'] = None

        if 'Route_LineDirection_Id' not in data:
            data['Route_LineDirection_Id'] = None

        if 'Type' not in data:
            data['Type'] = 'CO'
        if 'Priority' not in data:
            data['Priority'] = 1
        if 'date' not in data:
            data['date'] = datetime.datetime.now()

        if 'Route_Id' not in data:
            print('Route_Id is missing from the file!!!')
            return
        if 'Title' not in data:
            print('Title is missing from the file!!!')
            return
        if 'Content' not in data:
            print('Content is missing from the file!!!')
            return


        SysAuthor = User.objects.get(username='SysAPI')

        print('Data is ready to load')
        data['import_log'] = ''

        comments_objs = [] # empty it
        for i, row in data.iterrows():

            try:
                com_obj = Comment(
                    Route_Full_Id = row['Route_Full_Id'],
                    Route_LineDirection_Id = row['Route_LineDirection_Id'],
                    Route_Id = row['Route_Id'],
                    Type = row['Type'],
                    Priority = row['Priority'],
                    Title = row['Title'],
                    Content = row['Content'],
                    Author = SysAuthor,
                    date = row['date'],
                )

                comments_objs.append(com_obj)
                print(i)

            except Exception as e:
                print(e)
                print('row %s did not load' % i)
                data.iloc[i, data.columns.get_loc('import_log')] += 'failed to load line'
                #raise CommandError('row %s did not load' % i)

            if len(comments_objs) > 1000:

                loadPack = loadPack + 1
                try:
                    print('loading to DB - Start - loadPack:' +str(loadPack) + ' ts_objs len:' + str(len(comments_objs)))
                    Comment.objects.bulk_create(comments_objs) # load to DB
                    print('loading to DB - END - loadPack:' +str(loadPack))
                except Exception as e:
                    print('failed loading - e= ' + e)

                ts_objs = [] # empty it

        if comments_objs:
            print('loading to DB - last loadPack')
            Comment.objects.bulk_create(comments_objs) # load to DB

        end_time = timezone.now()

        file_name, file_extension = os.path.splitext(file_path)
        logFileName = file_name + '_import_log' + end_time.strftime("%d-%b-%Y(%H-%M-%S)") + file_extension

        data.to_csv(logFileName, encoding='utf-8-sig', index=False)

        self.stdout.write(
            self.style.SUCCESS(
                f"Loading CSV took: {(end_time-start_time).total_seconds()} seconds."
            )
        )
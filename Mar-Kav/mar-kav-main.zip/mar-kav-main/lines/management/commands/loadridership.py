from django.core.management.base import BaseCommand, CommandError
from lines.models import Line, Line_Direction
# from ridership.models import Ridership

import pandas as pd
import numpy as np
from datetime import datetime
import os
from django.utils import timezone
import json

class Command(BaseCommand):
    help = "Loads ridership data from CSV file."

    def add_arguments(self, parser):
        parser.add_argument("file_path", type=str)

    def handle(self, *args, **options):

        start_time = timezone.now()

        file_path = options["file_path"]

        data = pd.read_csv(file_path)
        data['import_log'] = ''
        data = data.replace({np.nan: None})

        data_n = str(data['מקט'].count())

        LineList = data['מקט'].unique().tolist()

        for singleLine in LineList:

            rtable = data[data['מקט'] == singleLine]
            Line_obj = Line.objects.get(Route_Id=singleLine)
            lineStationsData = []
            lineRidership = []

            for i, row in rtable.iterrows():

                try:
                    this_object_id = str(row['מקט']) + '-' + str(row['כיוון'])
                    print('Loading ' + this_object_id + ' - ' + str(i) + ' of ' + data_n)
                    Line_Direction_obj = Line_Direction.objects.get(Route_LineDirection_Id=this_object_id)

                    Ridership = {
                        'Avg_riders_per_KM' : row['ממוצע נוסעים לקילומטר'],  # ממוצע נוסעים לקילומטר
                        'Daily_riders' : row['נוסעים יומי'],  # נוסעים יומי
                        'Weekly_riders' : row['נוסעים שבועי'],  # נוסעים שבועי
                        'Avg_riders_per_ride' : row['ממוצע נוסעים לנסיעה (שבועי)'],  # ממוצע נוסעים לנסיעה (שבועי)
                        'Max_per_time_period' : row['ערך מקסימום בתקופת יום'],  # ערך מקסימום בתקופת יום
                        'Max_time_period': row['נסועה מקסימלית'],  # ערך מקסימום בתקופת יום

                        'Avg_speed': row['מהירות ממוצעת'],  # מהירות ממוצעת
                        'Avg_duration': row['משך נסיעה ממוצע (דקות)'],  # משך נסיעה ממוצע (דקות)
                        'Operational_Cost_per_rider': row['עלות תפעולית לנוסע'],  # עלות תפעולית לנוסע

                    }
                    lineRidership.append(Ridership)

                    Ridership_as_str = json.dumps(Ridership, indent=2, ensure_ascii=False)

                    StationsData = {
                        'Stop_Count' : row['מספר תחנות בקו - חלופה ראשית'],  # מספר תחנות בקו
                        'Singular_Stops' : row['תחנות שקו זה משרת בבלעדיות'],  # תחנות שקו זה משרת בבלעדיות
                        'Singular_Settlement' : row['ישובים שקו זה משרת בבלעדיות'],  # ישובים שקו זה משרת בבלעדיות
                    }
                    lineStationsData.append(StationsData)

                    Line_Direction_Data = json.loads(Line_Direction_obj.Line_Direction_Data)
                    Line_Direction_Data = {**Line_Direction_Data, **StationsData} # add and update
                    Line_Direction_Data_as_str = json.dumps(Line_Direction_Data, indent=2, ensure_ascii=False)

                    # save it
                    Line_Direction_obj.Line_Direction_Data = Line_Direction_Data_as_str
                    Line_Direction_obj.Line_Direction_Ridership = Ridership_as_str

                    Line_Direction_obj.save()

                except Exception as e:
                    print(e)
                    print('row %s did not load- Ridership' % i)
                    data.iloc[i, data.columns.get_loc('import_log')] += 'failed to load ridership'

            try:
                lineRidershipdf = pd.DataFrame(lineRidership)

                Ridership = {
                    'Avg_riders_per_KM': float(lineRidershipdf['Avg_riders_per_KM'].mean()),  # ממוצע נוסעים לקילומטר
                    'Daily_riders': int(lineRidershipdf['Daily_riders'].sum()),  # נוסעים יומי
                    'Weekly_riders': int(lineRidershipdf['Weekly_riders'].sum()),  # נוסעים שבועי
                    'Avg_riders_per_ride': float(lineRidershipdf['Avg_riders_per_ride'].mean()),  # ממוצע נוסעים לנסיעה (שבועי)
                    'Max_per_time_period': float(lineRidershipdf['Max_per_time_period'].max()),  # ערך מקסימום בתקופת יום
                    'Max_time_period': lineRidershipdf['Max_time_period'].iloc[0],  # ערך מקסימום בתקופת יום

                    'Avg_speed': float(lineRidershipdf['Avg_speed'].mean()),  # מהירות ממוצעת
                    'Avg_duration': float(lineRidershipdf['Avg_duration'].mean()),  # משך נסיעה ממוצע (דקות)
                    'Operational_Cost_per_rider': float(lineRidershipdf['Operational_Cost_per_rider'].mean()),  # עלות תפעולית לנוסע
                }
                Ridership_as_str = json.dumps(Ridership, indent=2, ensure_ascii=False)

                lineStationsDatadf = pd.DataFrame(lineStationsData)

                StationsData = {
                    'Stop_Count': int(lineStationsDatadf['Stop_Count'].max()),  # מספר תחנות בקו
                    'Singular_Stops': int(lineStationsDatadf['Singular_Stops'].sum()),  # תחנות שקו זה משרת בבלעדיות
                    'Singular_Settlement': lineStationsDatadf['Singular_Settlement'].iloc[0],  # ישובים שקו זה משרת בבלעדיות
                }

                Line_Data = json.loads(Line_obj.Line_Data)
                Line_Data = {**Line_Data, **StationsData}  # add and update
                Line_Data_as_str = json.dumps(Line_Data, indent=2, ensure_ascii=False)

                # save it
                Line_obj.Line_Data = Line_Data_as_str
                Line_obj.Line_Ridership = Ridership_as_str
                Line_obj.Ridership_Updated_on = str(datetime.now().strftime('%Y-%m-%d')) # today

                Line_obj.save()

            except Exception as e:
                print(e)
                print('Line data did not load on ' +str(singleLine))

        end_time = timezone.now()

        file_name, file_extension = os.path.splitext(file_path)
        logFileName = file_name + '_import_log' + end_time.strftime("%d-%b-%Y(%H-%M-%S)") + file_extension

        data.to_csv(logFileName, encoding='utf-8-sig', index=False)

        self.stdout.write(
            self.style.SUCCESS(
                f"Loading CSV took: {(end_time-start_time).total_seconds()} seconds."
            )
        )
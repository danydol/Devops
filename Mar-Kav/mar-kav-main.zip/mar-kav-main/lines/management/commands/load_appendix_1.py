from django.core.management.base import BaseCommand, CommandError
from lines.models import Line, Line_Direction, Line_Direction_Alternative

import pandas as pd
from datetime import datetime
import os
import json
from django.utils import timezone

class Command(BaseCommand):
    help = "Loads Appendix 1 data from EXCEL file."
    logFile = pd.DataFrame(columns=['message'])

    def LogThis(self, message: str):
        print(message)
        self.logFile.loc[len(self.logFile)] = [message]
    ################################

    def add_arguments(self, parser):
        parser.add_argument("file_path", type=str)


    def handle(self, *args, **options):

        start_time = timezone.now()

        self.LogThis('loading file')
        file_path = options["file_path"]

        file_name, file_extension = os.path.splitext(file_path)
        logFileName = file_name + '_import_log' + start_time.strftime("%d-%b-%Y(%H-%M-%S)") + '.csv'

        data = pd.read_csv(file_path)
        self.LogThis('file - read')

        try:
            # just in case...
            data.drop_duplicates(subset=['מקט',
                                         'כיוון',
                                         'חלופה',
                                         'מזהה החלופה',
                                         ], inplace=True)


            ##### LINES data ###################################################
            MainAlternative = data.loc[data.groupby('מקט')['כמות נסיעות שבועיות'].agg(pd.Series.idxmax)]

            linesData = MainAlternative[[
                'שם מפעיל',
                'אשכול',
                'מחוז',
                'מקט',
                'קו',
                'סוג קו',  # from main alternative
                'שם סוג שירות',  # from main alternative
                'ייחודיות הקו',  # from main alternative
                'גודל אוטובוס',  # from main alternative
                'סוג אוטובוס',  # from main alternative
                'תאריך הפעלה הראשונה',  # from main alternative
                'שם יישוב מוצא',  # Main
                'שם יישוב יעד',  # Main
                'אורך מסלול',  # Main
                'מאושר שבת',  # Main
            ]].copy()

            linesData['שם קו מלא'] = 'קו ' + linesData['קו'].astype(str) + \
                                     ' - ' + linesData['שם יישוב מוצא'] + ' <-> ' + linesData['שם יישוב יעד']
            linesData.loc[linesData['שם יישוב מוצא'] == linesData['שם יישוב יעד'], 'שם קו מלא'] = 'קו ' + \
                                    linesData['קו'].astype(str) + \
                                    ' - ' + linesData['שם יישוב מוצא']


            PivData = data.pivot_table(index=['מקט'],
                                       values=['כמות נסיעות יומית (ג)',  # Agregated
                                               'כמות נסיעות שבועיות',  # Agregated
                                               'ק"מ שבועי',  # Agregated
                                               ], aggfunc='sum')

            Agregated_data = pd.DataFrame(PivData.to_records())
            Agregated_data['ק"מ שבועי'] = Agregated_data['ק"מ שבועי'].astype(int)
            linesData = linesData.merge(Agregated_data, on='מקט', how='left')

            linesData = linesData[[
                'שם מפעיל',
                'אשכול',
                'מחוז',
                'מקט',
                'קו',
                'סוג קו',  # from main alternative
                'שם סוג שירות',  # from main alternative
                'ייחודיות הקו',  # from main alternative
                'גודל אוטובוס',  # from main alternative
                'סוג אוטובוס',  # from main alternative
                'תאריך הפעלה הראשונה',  # from main alternative
                'אורך מסלול',  # from main alternative
                'מאושר שבת',  # from main alternative

                'שם קו מלא',

                'כמות נסיעות יומית (ג)',  # Agregated
                'כמות נסיעות שבועיות',  # Agregated
                'ק"מ שבועי',  # Agregated
            ]].copy()

            linesData['תאריך הפעלה הראשונה'] = pd.to_datetime(linesData['תאריך הפעלה הראשונה'], infer_datetime_format=True)

            self.LogThis('line data ready')

            ################ Line Direction data

            MainAlternative = data.loc[data.groupby(['מקט', 'כיוון'])['כמות נסיעות שבועיות'].agg(pd.Series.idxmax)]
            linesDirectionData = MainAlternative[[
                'מקט',
                'כיוון',
                'שם יישוב מוצא',  # Main
                'שם יישוב יעד',  # Main
                'שם תחנת מוצא',  # Main
                'שם תחנת יעד',  # Main
                'שם תחנת יעד לפרסום', # Main
                'אורך מסלול',  # Main
            ]].copy()
            PivData = data.pivot_table(index=['מקט', 'כיוון'],
                                       values=['כמות נסיעות יומית (ג)',  # Agregated
                                               'כמות נסיעות שבועיות',  # Agregated
                                               'ק"מ שבועי',  # Agregated
                                               ], aggfunc='sum')

            Agregated_data = pd.DataFrame(PivData.to_records())
            Agregated_data['ק"מ שבועי'] = Agregated_data['ק"מ שבועי'].astype(int)
            linesDirectionData = linesDirectionData.merge(Agregated_data, on=['מקט', 'כיוון'], how='left')

            self.LogThis('Lines Direction - data ready')

            ################## Lines Direction Alternative data
            linesDirectionAlternativeData = data[[
                'מקט',
                'כיוון',
                'חלופה',
                'שם יישוב מוצא',
                'שם יישוב יעד',
                'שם תחנת מוצא',  # Main
                'שם תחנת יעד', # Main
                'שם תחנת יעד לפרסום',  # Main
                'אורך מסלול',
                'כמות נסיעות יומית (ג)',
                'כמות נסיעות שבועיות',
                'ק"מ שבועי',
                'מזהה החלופה',
            ]].copy()

        except BaseException as e:
            self.LogThis(str(e))
            self.LogThis('Failed to prep the file')
            self.logFile.to_csv(logFileName, encoding='utf-8-sig', index=False)
            return

        self.LogThis('Lines Direction Alternative - data ready')
        ################# now ready to load !!! ####################################################
        ###########################################################################

        # loop on all lines
        self.LogThis('start looping the lines')
        linesData_count = str(linesData['מקט'].count())

        for i, row in linesData.iterrows():
            print('Loading ' + str(i) + ' from ' + linesData_count)
            try:

                line_data_dict = {
                    'Line_Type': row['סוג קו'],  # עירוני וכדומה
                    'Service_Type': row['שם סוג שירות'],  # שם סוג שירות	מקומי מאסף
                    'Line_Property': row['ייחודיות הקו'],  # ייחודיות הקו - תלמידים, לילה, סדיר...
                    'Bus_Size': row['גודל אוטובוס'],  # סוג אוטובוס
                    'Bus_Type': row['סוג אוטובוס'],  # עירוני וכדומה
                    'Operation_Start_Date': row['תאריך הפעלה הראשונה'].strftime("%d-%m-%Y"),  # תאריך הפעלה הראשונה

                    'Daily_Rides_3': row['כמות נסיעות יומית (ג)'],  # כמות נסיעות יומית (ג)
                    'Weekly_rides': row['כמות נסיעות שבועיות'],  # כמות נסיעות שבועיות
                    'Weekly_KM': row['ק"מ שבועי'],  # ק"מ שבועי
                    'Route_KM': round(row['אורך מסלול'] / 1000 ,1),  # אורך מסלול בקילומטר
                    'Saturday_Approved': row['מאושר שבת'] == 'כן',  # אורך מסלול בקילומטרמאושר שבת
                }

                line_data_dict_as_str = json.dumps(line_data_dict, indent=2, ensure_ascii=False)

                lineDict = {
                    'Route_Id' : row['מקט'],  # מק"ט
                    'Agency_Name' : row['שם מפעיל'],  # אגד
                    'Cluster_Name' : row['אשכול'],  # אשכול
                    'Metropolin' : row['מחוז'],  # מחוז
                    'Line_Name' : row['קו'],  # שם הקו - מספר בדרך כלל
                    'Line_Type' : row['סוג קו'],  # עירוני וכדומה
                    'Service_Type' : row['שם סוג שירות'],  # שם סוג שירות	מקומי מאסף
                    'Line_Property' : row['ייחודיות הקו'],  # ייחודיות הקו - תלמידים, לילה, סדיר...
                    'Bus_Size' : row['גודל אוטובוס'],  # סוג אוטובוס
                    'Bus_Type' : row['סוג אוטובוס'],  # עירוני וכדומה
                    'Operation_Start_Date' : row['תאריך הפעלה הראשונה'],  # תאריך הפעלה הראשונה

                    'Line_full_name' : row['שם קו מלא'],  # שם קו מלא
                    'Daily_Rides_3' : row['כמות נסיעות יומית (ג)'],  # כמות נסיעות יומית (ג)
                    'Weekly_rides' : row['כמות נסיעות שבועיות'],  # כמות נסיעות שבועיות
                    'Weekly_KM' : row['ק"מ שבועי'],  # ק"מ שבועי

                    'Line_Data' : line_data_dict_as_str,  # LineData is the string of the dictionary above
                    'Line_updated_on' : str(datetime.now().strftime('%Y-%m-%d')),  # today!
                }

                lineObj, created = Line.objects.update_or_create(
                    Route_Id = row['מקט'],
                    defaults = lineDict,
                )

            except BaseException as e:
                self.LogThis(str(e))
                self.LogThis('Line %s did not load' % row['מקט'])
                continue

            # As we are updating this line - delete all previous data for directions and alternatives
            thisLine_linesDirections = Line_Direction.objects.filter(p_Line = lineObj)
            thisLine_linesDirections.delete()
            #############################################

            This_linesDirectionData = linesDirectionData[linesDirectionData['מקט'] == row['מקט']]
            This_linesDirectionAlternatives = linesDirectionAlternativeData[
                linesDirectionAlternativeData['מקט'] == row['מקט']]

            for LD_i, LD_row in This_linesDirectionData.iterrows():
                Route_LineDirection_id_ = str(LD_row['מקט']) + '-' + str(LD_row['כיוון'])  # מקט - כיוון

                try:

                    Line_Direction_Data_dict = {
                        'Daily_Rides_3': LD_row['כמות נסיעות יומית (ג)'],  # כמות נסיעות יומית (ג)
                        'Weekly_rides': LD_row['כמות נסיעות שבועיות'],  # כמות נסיעות שבועיות
                        'Weekly_KM': LD_row['ק"מ שבועי'],  # ק"מ שבועי
                        'Route_KM': round(LD_row['אורך מסלול'] / 1000 ,1),  # אורך מסלול בקילומטר
                        'Destination_Pub_Name': LD_row['שם תחנת יעד לפרסום'],
                    }

                    Line_Direction_Data_as_str = json.dumps(Line_Direction_Data_dict, indent=2, ensure_ascii=False)

                    Line_Direction_Dict = {
                        'p_Line' : lineObj,
                        'Route_LineDirection_Id' : Route_LineDirection_id_,  # מקט - כיוון
                        'Route_Id' : LD_row['מקט'],  # מק"ט
                        'Route_Direction' : LD_row['כיוון'],  # כיוון
                        'Origin_Name' : LD_row['שם יישוב מוצא'] + ' - ' + LD_row['שם תחנת מוצא'],  # מוצא
                        'Destination_Name' : LD_row['שם יישוב יעד'] + ' - ' + LD_row['שם תחנת יעד'],  # יעד
                        'Daily_Rides_3' : LD_row['כמות נסיעות יומית (ג)'],  # כמות נסיעות יומית (ג)
                        'Weekly_rides' : LD_row['כמות נסיעות שבועיות'],  # כמות נסיעות שבועיות
                        'Weekly_KM' : LD_row['ק"מ שבועי'],  # ק"מ שבועי
                        'Line_Direction_Data' : Line_Direction_Data_as_str,  # LineData is the string of the dictionary above
                    }

                    Line_Direction_obj, created = Line_Direction.objects.update_or_create(
                        p_Line=lineObj, Route_LineDirection_Id = Route_LineDirection_id_,
                        defaults=Line_Direction_Dict,
                    )

                except BaseException as e:
                    self.LogThis(str(e))
                    self.LogThis('Line_Direction_obj %s did not load' % Route_LineDirection_id_)
                    continue

                This_linesDirectionAlternativeData = This_linesDirectionAlternatives[
                    This_linesDirectionAlternatives['כיוון'] == LD_row['כיוון']]

                for LDA_i, LDA_row in This_linesDirectionAlternativeData.iterrows():

                    Route_Full_id_ = str(LDA_row['מקט']) + \
                        '-' + str(LDA_row['כיוון']) + \
                        '-' + str(LDA_row['חלופה'])  # מקט - כיוון - חלופה

                    try:
                        # Line_Direction_Alternative_obj = Line_Direction_Alternative(
                        #
                        #     p_Line_direction=Line_Direction_obj,
                        #
                        #     Route_Full_Id = Route_Full_id_, # מקט - כיוון - חלופה
                        #     Route_LineDirection_Id = Route_LineDirection_id_,  # מקט - כיוון
                        #     Route_Id = LDA_row['מקט'],  # מק"ט
                        #     Route_Alternative=LDA_row['חלופה'],  # אלטרנטיבה
                        #     Alternative_ID=LDA_row['מזהה החלופה'],  # מזהה חלופה
                        #
                        #     Origin_Name = LDA_row['שם יישוב מוצא'],  # מוצא
                        #     Destination_Name = LDA_row['שם יישוב יעד'],  # יעד
                        #
                        #     Daily_Rides_3 = LDA_row['כמות נסיעות יומית (ג)'],  # כמות נסיעות יומית (ג)
                        #     Weekly_rides = LDA_row['כמות נסיעות שבועיות'],  # כמות נסיעות שבועיות
                        #     Weekly_KM = LDA_row['ק"מ שבועי'],  # ק"מ שבועי
                        #     Line_Length = LDA_row['אורך מסלול'],
                        #
                        # )
                        # Line_Direction_Alternative_obj.save()

                        Line_Direction_Alternative_dict = {

                            'p_Line_direction' : Line_Direction_obj,

                            'Route_Full_Id' : Route_Full_id_, # מקט - כיוון - חלופה
                            'Route_LineDirection_Id' : Route_LineDirection_id_,  # מקט - כיוון
                            'Route_Id' : LDA_row['מקט'],  # מק"ט
                            'Route_Alternative' : LDA_row['חלופה'],  # אלטרנטיבה
                            'Alternative_ID' : LDA_row['מזהה החלופה'],  # מזהה חלופה

                            'Origin_Name' : LDA_row['שם יישוב מוצא'],  # מוצא
                            'Destination_Name' : LDA_row['שם יישוב יעד'],  # יעד

                            'Daily_Rides_3' : LDA_row['כמות נסיעות יומית (ג)'],  # כמות נסיעות יומית (ג)
                            'Weekly_rides' : LDA_row['כמות נסיעות שבועיות'],  # כמות נסיעות שבועיות
                            'Weekly_KM' : LDA_row['ק"מ שבועי'],  # ק"מ שבועי
                            'Line_Length' : LDA_row['אורך מסלול'],
                        }

                        Line_Direction_Alternative_obj, created = Line_Direction_Alternative.objects.update_or_create(
                            p_Line_direction=Line_Direction_obj, Route_Full_Id=Route_Full_id_,
                            defaults=Line_Direction_Alternative_dict,
                        )

                    except BaseException as e:
                        self.LogThis(str(e))
                        self.LogThis('Line_Direction_Alternative_obj %s did not load' % Route_Full_id_)
                        continue


        end_time = timezone.now()

        self.LogThis(f"Loading CSV took: {(end_time-start_time).total_seconds()} seconds.")
        self.logFile.to_csv(logFileName, encoding='utf-8-sig', index=False)

        self.stdout.write(
            self.style.SUCCESS(
                f"Loading CSV took: {(end_time-start_time).total_seconds()} seconds."
            )
        )
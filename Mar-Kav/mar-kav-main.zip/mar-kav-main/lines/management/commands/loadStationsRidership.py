from django.core.management.base import BaseCommand, CommandError
from stations_ridership.models import StationRidership

import pandas as pd
import numpy as np
import os
from django.utils import timezone

class Command(BaseCommand):
    help = "Delete and reLoads StationRidership data from CSV file."

    def add_arguments(self, parser):
        parser.add_argument("file_path", type=str)

    def handle(self, *args, **options):

        start_time = timezone.now()
        loadPack = 0

        # First - delete previous data
        print('Deleting StationRidership data')
        try:
            StationRidership.objects.all().delete()
        except:
            raise CommandError('deleting StationRidership data - did not work')

        # now load
        print('loading StationRidership data')

        file_path = options["file_path"]

        data = pd.read_csv(file_path)
        data['import_log'] = ''
        data = data.replace({np.nan: None})

        SR_objs = [] # empty it

        for i, row in data.iterrows():

            try:

                SRidership_obj = StationRidership(

                    Route_Id=row['Route_Id'],  # מק"ט
                    Route_LineDirection_Id = row['LineDirection'],  # מקט - כיוון
                    Route_Full_Id = row['Route_Full_Id'],  # מקט - כיוון - חלופה

                    Stop_name = row['Stop_name'],  # שם תחנה
                    Stop_ID = row['Stop_id'],  # מקט תחנה
                    Stop_line_order = row['Stop_line_order'],  # סידורי תחנה

                    Lat = row['Lat'],  # קואורדינטות
                    Long = row['Long'],  # קואורדינטות

                    Day_1 = row['1'],  # ממוצע עולים בתחנה ביום זה
                    Day_2 = row['2'],  # ממוצע עולים בתחנה ביום זה
                    Day_3 = row['3'],  # ממוצע עולים בתחנה ביום זה
                    Day_4 = row['4'],  # ממוצע עולים בתחנה ביום זה
                    Day_5 = row['5'],  # ממוצע עולים בתחנה ביום זה
                    Day_6 = row['6'],  # ממוצע עולים בתחנה ביום זה
                    Day_7 = row['7'],  # ממוצע עולים בתחנה ביום זה
                    Week=row['Week'],  # ממוצע עולים בתחנה ביום זה

                    Attributes = row['attribute'],  # מאפיינים לתחנה זו בקו זה
                )

                SR_objs.append(SRidership_obj)

            except Exception as e:
                print(e)
                print('row %s did not load- StationRidership' % i)
                data.iloc[i, data.columns.get_loc('import_log')] += 'failed to load line'

            if len(SR_objs) > 999:

                loadPack = loadPack + 1

                try:
                    print('loading to DB - loadPack:' +str(loadPack) + ' shapes_objs len:' + str(len(SR_objs)))
                    StationRidership.objects.bulk_create(SR_objs) # load to DB

                except Exception as e:
                    print('failed loading - e= ' + e)

                SR_objs = [] # empty it

        if len(SR_objs) > 0:
            print('loading to DB - last loadPack')
            StationRidership.objects.bulk_create(SR_objs) # load to DB

        end_time = timezone.now()

        file_name, file_extension = os.path.splitext(file_path)
        logFileName = file_name + '_import_log' + end_time.strftime("%d-%b-%Y(%H-%M-%S)") + file_extension

        data.to_csv(logFileName, encoding='utf-8-sig', index=False)

        self.stdout.write(
            self.style.SUCCESS(
                f"Loading CSV took: {(end_time-start_time).total_seconds()} seconds."
            )
        )
from django.core.management.base import BaseCommand, CommandError
from time_series.models import TimeSeries

import pandas as pd
# import numpy as np
import os
from django.utils import timezone

class Command(BaseCommand):
    help = "Loads app 4 as csv"

    def add_arguments(self, parser):
        parser.add_argument("file_path", type=str)

    def handle(self, *args, **options):

        # First - delete previous data
        print('deleting previous data')
        try:
            TimeSeries.objects.filter(Type = 'RE', Index = 'LD').delete()
        except:
            raise CommandError('deleting TimeSeries data - did not work')

        # now load
        print('loading appendix 4 data')

        start_time = timezone.now()
        loadPack = 0

        file_path = options["file_path"]

        data = pd.read_csv(file_path)

        print('Preparing the file')

        # -------------------------
        data['code'] = data['מקט'].astype(str) + '-' + data['כיוון'].astype(str)
        data = data[data['code'].str.len() == 7]

        data2 = data[['code', 'יום', 'שעת יציאה מהתחנה']].copy()

        data2['h'] = data2['שעת יציאה מהתחנה'].str[:2]
        data2['h'] = data2['h'].astype(int)

        data2.rename(columns={'יום': 'weekday'}, inplace=True)

        # adjust hours that are after 24:00
        data2.loc[data2['h'] > 23, 'weekday'] = data2['weekday'] + 1
        data2.loc[data2['h'] > 23, 'h'] = data2['h'] % 24
        data2.loc[data2['weekday'] == 8, 'weekday'] = 1


        PivData = data2.pivot_table(index=['code', 'weekday'], columns=['h'],
                                    values=['שעת יציאה מהתחנה'], aggfunc='count')
        R_data = pd.DataFrame(PivData.to_records())

        R_data = R_data.fillna(0)
        R_data.iloc[:, 1:] = R_data.iloc[:, 1:].astype(int)
        R_data['Observation24H'] = R_data.iloc[:, 2:50].apply(lambda row: ','.join(row.values.astype(str)), axis=1)

        data = R_data[['code', 'weekday', 'Observation24H']].copy()

        # -----------------------------------

        print('Data is ready to load')
        data['import_log'] = ''

        ts_objs = [] # empty it
        for i, row in data.iterrows():

            try:
                time_s_obj = TimeSeries(
                    Type = 'RE',
                    Index = 'LD',
                    Section = 'D' + str(row['weekday']),
                    Index_Id = row['code'],
                    Observation24H = row['Observation24H'],
                )

                ts_objs.append(time_s_obj)
                print(i)

            except Exception as e:
                print(e)
                print('row %s did not load' % i)
                data.iloc[i, data.columns.get_loc('import_log')] += 'failed to load line'
                #raise CommandError('row %s did not load' % i)

            if len(ts_objs) > 1000:

                loadPack = loadPack + 1
                try:
                    print('loading to DB - Start - loadPack:' +str(loadPack) + ' ts_objs len:' + str(len(ts_objs)))
                    TimeSeries.objects.bulk_create(ts_objs) # load to DB
                    print('loading to DB - END - loadPack:' +str(loadPack))
                except Exception as e:
                    print('failed loading - e= ' + e)

                ts_objs = [] # empty it

        if ts_objs:
            print('loading to DB - last loadPack')
            TimeSeries.objects.bulk_create(ts_objs) # load to DB

        end_time = timezone.now()

        file_name, file_extension = os.path.splitext(file_path)
        logFileName = file_name + '_import_log' + end_time.strftime("%d-%b-%Y(%H-%M-%S)") + file_extension

        data.to_csv(logFileName, encoding='utf-8-sig', index=False)

        self.stdout.write(
            self.style.SUCCESS(
                f"Loading CSV took: {(end_time-start_time).total_seconds()} seconds."
            )
        )
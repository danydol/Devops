from django.core.management.base import BaseCommand, CommandError
from shapes.models import Shape

import pandas as pd
import numpy as np
import os
from django.utils import timezone

class Command(BaseCommand):
    help = "Loads route shapes data from CSV file (from GTFS and cleanup python code)"

    def add_arguments(self, parser):
        parser.add_argument("file_path", type=str)

    def handle(self, *args, **options):

        # First - delete previous data
        print('deleting shapes data')
        try:
            Shape.objects.all().delete()
        except:
            raise CommandError('deleting shapes data - did not work')

        # now load
        print('loading shapes data')

        start_time = timezone.now()
        loadPack = 0

        file_path = options["file_path"]

        data = pd.read_csv(file_path)
        data['import_log'] = ''
        # data = data.replace({np.nan: None})

        shapes_objs = [] # empty it
        for i, row in data.iterrows():

            try:
                shape_obj = Shape(
                    Route_Full_Id = row['Route_Full_Id'],
                    Route_LineDirection_Id = row['Route_LineDirection_Id'],
                    Route_Line_Id = str(row['Route_Line_Id']),
                    route_points = row['route_points'],
                )

                shapes_objs.append(shape_obj)

            except Exception as e:
                print(e)
                print('row %s did not load' % i)
                data.iloc[i, data.columns.get_loc('import_log')] += 'failed to load line'
                #raise CommandError('row %s did not load' % i)

            if len(shapes_objs) > 999:

                loadPack = loadPack + 1
                try:
                    print('loading to DB - Start - loadPack:' +str(loadPack) + ' shapes_objs len:' + str(len(shapes_objs)))
                    Shape.objects.bulk_create(shapes_objs) # load to DB
                    print('loading to DB - END - loadPack:' +str(loadPack))
                except Exception as e:
                    print('failed loading - e= ' + e)

                shapes_objs = [] # empty it

        if shapes_objs:
            print('loading to DB - last loadPack')
            Shape.objects.bulk_create(shapes_objs) # load to DB

        end_time = timezone.now()

        file_name, file_extension = os.path.splitext(file_path)
        logFileName = file_name + '_import_log' + end_time.strftime("%d-%b-%Y(%H-%M-%S)") + file_extension

        data.to_csv(logFileName, encoding='utf-8-sig', index=False)

        self.stdout.write(
            self.style.SUCCESS(
                f"Loading CSV took: {(end_time-start_time).total_seconds()} seconds."
            )
        )
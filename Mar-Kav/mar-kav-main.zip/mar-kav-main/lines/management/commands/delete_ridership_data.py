from django.core.management.base import BaseCommand, CommandError
from lines.models import Line, Line_Direction, Line_Direction_Alternative
from ridership.models import Ridership

class Command(BaseCommand):
    help = 'Closes the specified poll for voting'

    def add_arguments(self, parser):
        parser.add_argument('selectOpp', type=str)

    def handle(self, *args, **options):

        selectOpp = options["selectOpp"]
        print(selectOpp)

        # --------------------------------
        if ((selectOpp == 'Lines') or (selectOpp == 'All')):
            print('Deleting Line objects')
            try:
                Line.objects.all().delete()
            except BaseException as e:
                raise CommandError('Line - did not work:' + str(e))
        else:
            print('NOT Deleting Line objects')

        # --------------------------------
        if ((selectOpp == 'Ridership') or (selectOpp == 'All')):
            print('Deleting Ridership objects')
            try:
                Ridership.objects.all().delete()

            except BaseException as e:
                raise CommandError('Ridership - did not work:' + str(e))

        else:
            print('NOT Deleting Ridership objects')

        self.stdout.write(self.style.SUCCESS('Successfully deleted'))
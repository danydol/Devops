from django.core.management.base import BaseCommand, CommandError
from lines.models import Line

class Command(BaseCommand):
    help = 'Closes the specified poll for voting'

    def add_arguments(self, parser):
        parser.add_argument('lineID', nargs='+', type=int)

    def handle(self, *args, **options):
         for line_id in options['lineID']:
            try:
                line_obj = Line.objects.get(id=line_id)
            except Line.DoesNotExist:
                raise CommandError('Line "%s" does not exist' % line_id)

            # line_obj.opened = False
            # line_obj.save()
            print(line_obj.Cluster_Name)

            # self.stdout.write(self.style.SUCCESS('Successfully closed poll "%s"' % line_obj))
from django.core.management.base import BaseCommand, CommandError
from lines.models import Line
# from ridership.models import Ridership

import pandas as pd
import numpy as np
import os
from django.utils import timezone
import json

class Command(BaseCommand):
    help = "Loads ridership historical data from CSV file."

    def add_arguments(self, parser):
        parser.add_argument("file_path", type=str)

    def handle(self, *args, **options):

        start_time = timezone.now()

        file_path = options["file_path"]

        data = pd.read_csv(file_path)
        log = data.copy()
        log['import_log'] = ''
        data = data.replace({np.nan: None})
        data['RouteID'] = data['RouteID'].astype(int).astype(str)
        data = data.round(1)

        data_n = str(data['RouteID'].count())

        print('loading file with ' + str(data_n) + ' lines')

        for i, row in data.iterrows():

            try:

                RouteID = row['RouteID']

                Line_obj = Line.objects.get(Route_Id=RouteID)
                Line_RHistory = row.to_dict()
                del Line_RHistory['RouteID']

                if Line_obj.Line_RidershipHistory:
                    Line_RidershipHistory = json.loads(Line_obj.Line_RidershipHistory)
                else:
                    Line_RidershipHistory = {}

                Line_RidershipHistory = {**Line_RidershipHistory, **Line_RHistory}  # add and update

                Ridership_as_str = json.dumps(Line_RidershipHistory, indent=2, ensure_ascii=False)

                # save it
                Line_obj.Line_RidershipHistory = Ridership_as_str

                Line_obj.save()

            except Exception as e:
                print(e)
                print('Line data did not load on ' + str(RouteID))
                log.loc[log['RouteID'] == RouteID, 'import_log'] = 'Did not load: ' + str(e)

        end_time = timezone.now()

        file_name, file_extension = os.path.splitext(file_path)
        logFileName = file_name + '_import_log' + end_time.strftime("%d-%b-%Y(%H-%M-%S)") + file_extension

        log.to_csv(logFileName, encoding='utf-8-sig', index=False)

        self.stdout.write(
            self.style.SUCCESS(
                f"Loading CSV took: {(end_time-start_time).total_seconds()} seconds."
            )
        )
from django.core.management.base import BaseCommand, CommandError
from time_series.models import TimeSeries

import pandas as pd
# import numpy as np
import os
from django.utils import timezone

class Command(BaseCommand):
    help = "Loads Tikufim data From DataGov CSV file (get last month, cleanup and load)"

    def add_arguments(self, parser):
        parser.add_argument("file_path", type=str)

    def handle(self, *args, **options):

        # First - delete previous data
        print('deleting previous data')
        try:
            TimeSeries.objects.filter(Type = 'TC', Index = 'LD').delete()
        except:
            raise CommandError('deleting TimeSeries data - did not work')

        # now load
        print('loading TimeSeries data')

        start_time = timezone.now()
        loadPack = 0

        file_path = options["file_path"]

        data = pd.read_csv(file_path, encoding = "ISO-8859-8")
        # data['import_log'] = ''

        print('Preparing the file')

        data = data[data['OfficeLineId'] > 9999]
        data = data[data['OfficeLineId'] < 100000]

        # get the data from last month
        data = data[data['month_key'] == data['month_key'].max()]

        df_unpivoted = data.melt(id_vars=['OperatorId',
                                          'operator_nm',
                                          'ClusterId',
                                          'cluster_nm',
                                          'OperatorLineId',
                                          'OfficeLineId',
                                          'Direction',
                                          'hour_a',
                                          'year_key',
                                          'month_key'], var_name='day', value_name='num_of_tickets')

        data2 = df_unpivoted[~df_unpivoted['num_of_tickets'].isnull()]

        data3 = data2[['OfficeLineId', 'Direction', 'year_key', 'month_key', 'day', 'hour_a', 'num_of_tickets']].copy()
        data3['code'] = data3['OfficeLineId'].astype(str) + '-' + data3['Direction'].astype(str)
        data3['date'] = data3['day'].astype(str) + '/' + data3['month_key'].astype(str) + '/' + data3['year_key'].astype(str)
        print(data3['date'].head())
        data3['date'] = pd.to_datetime(data3['date'], format = '%d/%m/%Y')

        data3['weekday'] = (data3['date'].dt.weekday + 1) % 7 + 1

        if data3['hour_a'].nunique() != 24:
            print('BUG!!!! less then 24 hours in file!!!')
            return

        PivData = data3.pivot_table(index=['code', 'weekday'], columns=['hour_a'],
                                    values=['num_of_tickets'], aggfunc='mean')

        data = pd.DataFrame(PivData.to_records())
        data = round(data, 1)
        data.fillna(0, inplace=True)
        data['Observation24H'] = data.iloc[:, 2:50].apply(lambda row: ','.join(row.values.astype(str)), axis=1)
        data = data[['code', 'weekday', 'Observation24H']].copy()

        print('Data is ready to load')
        data['import_log'] = ''

        ts_objs = [] # empty it
        for i, row in data.iterrows():

            try:
                time_s_obj = TimeSeries(
                    Type = 'TC',
                    Index = 'LD',
                    Section = 'D' + str(row['weekday']),
                    Index_Id = row['code'],
                    Observation24H = row['Observation24H'],
                )

                ts_objs.append(time_s_obj)
                print(i)

            except Exception as e:
                print(e)
                print('row %s did not load' % i)
                data.iloc[i, data.columns.get_loc('import_log')] += 'failed to load line'
                #raise CommandError('row %s did not load' % i)

            if len(ts_objs) > 1000:

                loadPack = loadPack + 1
                try:
                    print('loading to DB - Start - loadPack:' +str(loadPack) + ' ts_objs len:' + str(len(ts_objs)))
                    TimeSeries.objects.bulk_create(ts_objs) # load to DB
                    print('loading to DB - END - loadPack:' +str(loadPack))
                except Exception as e:
                    print('failed loading - e= ' + e)

                ts_objs = [] # empty it

        if ts_objs:
            print('loading to DB - last loadPack')
            TimeSeries.objects.bulk_create(ts_objs) # load to DB

        end_time = timezone.now()

        file_name, file_extension = os.path.splitext(file_path)
        logFileName = file_name + '_import_log' + end_time.strftime("%d-%b-%Y(%H-%M-%S)") + file_extension

        data.to_csv(logFileName, encoding='utf-8-sig', index=False)

        self.stdout.write(
            self.style.SUCCESS(
                f"Loading CSV took: {(end_time-start_time).total_seconds()} seconds."
            )
        )
from django.core.management.base import BaseCommand, CommandError
from graphs_data.models import GraphData

import pandas as pd
import numpy as np
import os
from django.utils import timezone

class Command(BaseCommand):
    help = "Loads Graph data from CSV file (after prep code)"

    def add_arguments(self, parser):
        parser.add_argument("file_path", type=str)
        parser.add_argument("graphType", type=str)

    def handle(self, *args, **options):

        file_path = options["file_path"]
        graphType = options["graphType"]

        # First - delete previous data
        print('deleting GraphData loaded data from DB:' + graphType)
        # We should only delete data from a specific file type. not all
        try:
            GraphData.objects.filter(Type = graphType).delete()
        except:
            raise CommandError('deleting GraphData data - did not work')

        # now load
        print('loading GraphData data')

        start_time = timezone.now()
        loadPack = 0

        data = pd.read_csv(file_path)
        data['import_log'] = ''
        # data = data.replace({np.nan: None})

        if not ('Section_2' in data.columns):
            data['Section_2'] = None

        GraphData_objs = [] # empty it
        for i, row in data.iterrows():

            try:
                GraphData_obj = GraphData(
                    Type = row['Type'],
                    Section = row['Section'],
                    Section_2 = row['Section_2'],
                    Index = row['Index'],
                    Index_Id = row['Index_Id'],
                    Data = row['Data'],
                )

                GraphData_objs.append(GraphData_obj)

            except Exception as e:
                print(e)
                print('row %s did not load' % i)
                data.iloc[i, data.columns.get_loc('import_log')] += 'failed to load line'
                #raise CommandError('row %s did not load' % i)

            if len(GraphData_objs) > 999:

                loadPack = loadPack + 1
                try:
                    print('loading to DB - Start - loadPack:' +str(loadPack) + ' GraphData_objs len:' + str(len(GraphData_objs)))
                    GraphData.objects.bulk_create(GraphData_objs) # load to DB
                    print('loading to DB - END - loadPack:' +str(loadPack))
                except Exception as e:
                    print('failed loading - e= ' + e)

                GraphData_objs = [] # empty it

        if GraphData_objs:
            print('loading to DB - last loadPack')
            GraphData.objects.bulk_create(GraphData_objs) # load to DB

        end_time = timezone.now()

        file_name, file_extension = os.path.splitext(file_path)
        logFileName = file_name + '_import_log' + end_time.strftime("%d-%b-%Y(%H-%M-%S)") + file_extension

        data.to_csv(logFileName, encoding='utf-8-sig', index=False)

        self.stdout.write(
            self.style.SUCCESS(
                f"Loading CSV took: {(end_time-start_time).total_seconds()} seconds."
            )
        )
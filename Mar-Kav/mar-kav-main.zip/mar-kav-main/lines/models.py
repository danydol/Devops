from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator
from django import template

# import datetime

register = template.Library()

# Create your models here.
class Line(models.Model):

    Route_Id = models.PositiveIntegerField(db_index=True, validators=[MinValueValidator(10000),
                                                         MaxValueValidator(100000)]) # מק"ט

    Agency_Name = models.CharField(max_length=100) # אגד
    Cluster_Name = models.CharField(max_length=100) # אשכול
    Metropolin = models.CharField(max_length=100) # מחוז

    Line_Name = models.CharField(max_length=10) # שם הקו - מספר בדרך כלל

    Line_Type = models.CharField(max_length=30) # עירוני וכדומה
    Service_Type = models.CharField(max_length=30) # שם סוג שירות	מקומי מאסף
    Line_Property = models.CharField(max_length=30) # ייחודיות הקו - תלמידים, לילה, סדיר...
    Bus_Size = models.CharField(max_length=20) # סוג אוטובוס
    Bus_Type = models.CharField(max_length=30) # עירוני וכדומה
    Operation_Start_Date = models.DateField() # תאריך הפעלה הראשונה

    Line_full_name = models.CharField(max_length=120) # שם קו מלא
    Daily_Rides_3  = models.PositiveIntegerField(validators=[MinValueValidator(0),
                                     MaxValueValidator(1000)]) # כמות נסיעות יומית (ג)
    Weekly_rides = models.PositiveIntegerField(validators=[MinValueValidator(0),
                                     MaxValueValidator(10000)])  # כמות נסיעות שבועיות
    Weekly_KM = models.PositiveIntegerField(validators=[MinValueValidator(1),
                                    MaxValueValidator(100000)]) # ק"מ שבועי

    Line_Data = models.TextField(null=True, blank=True)
    Line_Ridership = models.TextField(null=True, blank=True)
    Line_RidershipHistory = models.TextField(null=True, blank=True)

    Line_updated_on = models.DateField(null=True, blank=True)
    Ridership_Updated_on = models.DateField(null=True, blank=True)

##########################################################################
class Line_Direction(models.Model):
    p_Line = models.ForeignKey(Line, on_delete=models.CASCADE, related_name='line_directions')

    Route_LineDirection_Id = models.CharField(db_index=True, max_length=10) # מקט - כיוון

    Route_Id = models.PositiveIntegerField(validators=[MinValueValidator(10000),
                                                         MaxValueValidator(100000)]) # מק"ט

    Route_Direction = models.PositiveIntegerField(validators=[MinValueValidator(1),
                                                         MaxValueValidator(3)]) # כיוון

    Origin_Name = models.CharField(max_length=50) # מוצא + שם תחנת מוצא

    Destination_Name = models.CharField(max_length=50) # יעד + שם תחנת יעד

    Daily_Rides_3  = models.PositiveIntegerField(validators=[MinValueValidator(0),
                                     MaxValueValidator(1000)]) # כמות נסיעות יומית (ג)
    Weekly_rides = models.PositiveIntegerField(validators=[MinValueValidator(0),
                                     MaxValueValidator(10000)])  # כמות נסיעות שבועיות
    Weekly_KM = models.PositiveIntegerField(validators=[MinValueValidator(1),
                                    MaxValueValidator(100000)]) # ק"מ שבועי

    Line_Direction_Data = models.TextField(null=True, blank=True)

    Line_Direction_Ridership = models.TextField(null=True, blank=True)

##########################################################################
class Line_Direction_Alternative(models.Model):
    p_Line_direction = models.ForeignKey(Line_Direction, on_delete=models.CASCADE, related_name='line_direction_alts')

    Route_Full_Id = models.CharField(max_length=12) # מקט - כיוון - חלופה
    Route_LineDirection_Id = models.CharField(max_length=10) # מקט - כיוון
    Route_Id = models.PositiveIntegerField(validators=[MinValueValidator(10000),
                                                         MaxValueValidator(100000)]) # מק"ט

    Route_Alternative = models.CharField(max_length=3) # אלטרנטיבה

    Origin_Name = models.CharField(max_length=30) # מוצא
    Destination_Name = models.CharField(max_length=30) # יעד

    Alternative_ID = models.PositiveIntegerField(validators=[MinValueValidator(10000),
                                                         MaxValueValidator(100000)]) # מזהה חלופה

    Daily_Rides_3  = models.PositiveIntegerField(validators=[MinValueValidator(0),
                                     MaxValueValidator(1000)]) # כמות נסיעות יומית (ג)
    Weekly_rides = models.PositiveIntegerField(validators=[MinValueValidator(0),
                                     MaxValueValidator(10000)])  # כמות נסיעות שבועיות

    Line_Length = models.PositiveIntegerField(validators=[MinValueValidator(1),
                                    MaxValueValidator(1000)]) # אורך מסלול (קמ)
    Weekly_KM = models.PositiveIntegerField(validators=[MinValueValidator(1),
                                    MaxValueValidator(100000)]) # ק"מ שבועי

    Line_Direction_Alternative_Data = models.TextField(null=True, blank=True)


from django import template
from django.template.defaultfilters import stringfilter
import json

# to be used with {% load mk_extras %} ###########

register = template.Library()

@register.filter
@stringfilter
def HTmarkReplace(value):
    return value.replace("#", "HT")


@register.filter(name='jsonify')
def jsonify(data):
    if isinstance(data, dict):
        return data
    else:
        return json.loads(data)

@register.filter(name='is_Planner')
def is_Planner(user):
    ret_val = False

    if user.is_authenticated:
        ret_val = user.email.endswith('@adalya.co.il')
        ret_val = ret_val or user.groups.filter(name='Planner').exists()

    return ret_val
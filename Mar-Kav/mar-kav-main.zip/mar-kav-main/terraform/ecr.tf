resource "aws_ecr_repository" "my_app_repo" {
  name = "my-app-repo"

  image_tag_mutability = "MUTABLE"

  image_scanning_configuration {
    scan_on_push = true
  }

  tags = {
    Environment = "dev"
    Name        = "my-app-repo"
  }
}
resource "aws_iam_role" "grafana_task_execution" {
  name = "grafana_task_execution"

  assume_role_policy = jsonencode({
    Version = "2012-10-17",
    Statement = [{
      Action = "sts:AssumeRole",
      Principal = {
        Service = "ecs-tasks.amazonaws.com"
      },
      Effect = "Allow",
      Sid    = ""
    }]
  })
}


resource "aws_iam_role_policy_attachment" "grafana_efs_access" {
 role = aws_iam_role.grafana_task_execution.name
 policy_arn = "arn:aws:iam::aws:policy/AmazonElasticFileSystemFullAccess"
}


resource "aws_iam_role_policy_attachment" "grafana_cloudwatch" {
  role       = aws_iam_role.grafana_task_execution.name
  policy_arn = "arn:aws:iam::aws:policy/CloudWatchReadOnlyAccess"
}




resource "aws_iam_policy" "access_loki_logs" {
  name        = "GrafanaAccessLoki"
  description = "Allow Grafana to access Loki logs"

  policy = jsonencode({
    Version = "2012-10-17",
    Statement = [
      {
        Effect = "Allow",
        Action = [
          "logs:DescribeLogGroups",
          "logs:GetLogEvents",
          "logs:FilterLogEvents"
        ],
        Resource = "*"
      }
    ]
  })
}

resource "aws_iam_role_policy_attachment" "grafana_loki" {
  role       = aws_iam_role.grafana_task_execution.name
  policy_arn = aws_iam_policy.access_loki_logs.arn
}

resource "aws_iam_role_policy" "ecs_exec_policy" {
  name = "ECSExecPolicy"
  role = aws_iam_role.grafana_task_execution.id

  policy = jsonencode({
    Version = "2012-10-17",
    Statement = [
      {
        Effect   = "Allow",
        Action   = [
          "ssmmessages:CreateControlChannel",
          "ssmmessages:CreateDataChannel",
          "ssmmessages:OpenControlChannel",
          "ssmmessages:OpenDataChannel"
        ],
        Resource = "*"
      }
    ]
  })
}







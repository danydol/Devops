resource "aws_ecs_cluster" "main" {
  name = "main-cluster"

   setting {
    name  = "containerInsights"
    value = "enabled"
  }

   setting {
    name  = "containerInsights"
    value = "enabled"
  }

  tags = {
    Name = "main-cluster"
  }
}


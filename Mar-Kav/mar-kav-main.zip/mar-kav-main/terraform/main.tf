
provider "aws" {
  region = "il-central-1"
  profile = "AWSAdministratorAccess-767828724805"
}


data "aws_vpc" "selected" {
  id = var.vpc_id
}

# Load existing private subnets

data "aws_subnet" "private_subnets" {
  for_each = toset(var.private_subnet_ids)
  id       = each.value
}

# Load existing public subnets

data "aws_subnet" "public_subnets" {
  for_each = toset(var.public_subnet_ids)
  id       = each.value
}

output "vpc_id" {
  value = data.aws_vpc.selected.id
}

output "private_subnet_ids" {
  value = [for s in data.aws_subnet.private_subnets : s.id]
}

output "public_subnet_ids" {
  value = [for s in data.aws_subnet.public_subnets : s.id]
}
  





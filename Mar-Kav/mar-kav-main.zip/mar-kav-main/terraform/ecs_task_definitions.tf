resource "aws_ecs_task_definition" "grafana" {
  family                   = "grafana"
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = "256"
  memory                   = "512"
  execution_role_arn       = aws_iam_role.grafana_task_execution.arn
  task_role_arn            = aws_iam_role.grafana_task_execution.arn

  container_definitions = jsonencode([
    {
      name      = "grafana"
      image     = "grafana/grafana:latest"
      essential = true
      portMappings = [
        {
          containerPort = 3000
          hostPort      = 3000
          protocol      = "tcp"
        }
      ]
      logConfiguration = {
        logDriver = "awslogs"
        options = {
          awslogs-group         = "/ecs/grafana"
          awslogs-region        = var.aws_region
          awslogs-stream-prefix = "ecs"
        }
      }
      mountPoints = [
        {
          sourceVolume  = "grafana-storage"
          containerPath = "/var/lib/grafana"
        }
      ]
      environment = [
        {
          name  = "GF_SMTP_ENABLED"
          value = "true"
        },
        {
          name  = "GF_SMTP_HOST"
          value = var.smtp_host
        },
        {
          name  = "GF_SMTP_USER"
          value = var.smtp_user
        },
        {
          name  = "GF_SMTP_PASSWORD"
          value = var.smtp_password
        },
        {
          name  = "GF_SMTP_FROM_ADDRESS"
          value = var.smtp_from
        },
        {
          name  = "GF_LOKI_URL"
          value = var.grafana_loki_url
        },
        {
          name  = "GF_PATHS_CONFIG"
          value = "/var/lib/grafana/grafana.ini"
        }
      ]
    }
  ])

  volume {
    name = "grafana-storage"
    efs_volume_configuration {
      file_system_id     = aws_efs_file_system.grafana_efs.id
      root_directory     = "/"
      transit_encryption = "ENABLED"
      authorization_config {
        access_point_id = aws_efs_access_point.grafana.id
        iam             = "ENABLED"
      }
    }
  }

  tags = {
    Name = "grafana-task"
  }
}

resource "aws_ecs_task_definition" "loki" {
  family                   = "loki"
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = "256"
  memory                   = "512"

  container_definitions = jsonencode([
    {
      name      = "loki"
      image     = "grafana/loki:latest"
      essential = true
      portMappings = [
        {
          containerPort = 3100
          hostPort      = 3100
          protocol      = "tcp"
        }
      ]
    }
  ])

  tags = {
    Name = "loki-task"
  }
}

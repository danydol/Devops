resource "aws_efs_file_system" "grafana_efs" {
  creation_token = "grafana-efs"
  lifecycle_policy {
    transition_to_ia = "AFTER_7_DAYS"
  }
}
resource "aws_efs_mount_target" "grafana_mount" {
  count          = 1 # or use length(var.private_subnets) for multi-AZ
  file_system_id = aws_efs_file_system.grafana_efs.id
  subnet_id      = "subnet-0e3ee09b7d4794d45" # Replace with your subnet
  security_groups = [aws_security_group.efs.id]
}


variable "vpc_id" {
  description = "The ID of the existing VPC"
  type        = string
}

variable "private_subnet_ids" {
  description = "List of existing private subnet IDs"
  type        = list(string)
}

variable "public_subnet_ids" {
  description = "List of existing public subnet IDs"
  type        = list(string)
}
variable "aws_region" {
  type    = string
  default = "il-central-1"
}

variable "smtp_host" {
  type    = string
  default = "smtp.gmail.com:587"
}

variable "smtp_user" {
  type = string
}

variable "smtp_password" {
  type      = string
  sensitive = true
}

variable "smtp_from" {
  type = string
}

variable "grafana_loki_url" {
  type    = string
  default = "http://localhost:3100"
}

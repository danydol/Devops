resource "aws_iam_role_policy" "grafana_logs" {
  name = "grafana-logs-policy"
  role = aws_iam_role.grafana_task_execution.name

  policy = jsonencode({
    Version = "2012-10-17",
    Statement = [
      {
        Effect = "Allow",
        Action = [
          "logs:CreateLogStream",
          "logs:PutLogEvents"
        ],
        Resource = "*"
      }
    ]
  })
}

resource "aws_lb" "nlb" {
  name               = "grafana-nlb"
  internal           = true
  load_balancer_type = "network"
  subnets            = var.public_subnet_ids  

  tags = {
    Name = "grafana-nlb"
  }
}

resource "aws_lb_target_group" "grafana" {
  name     = "grafana-tg"
  port     = 3000
  protocol = "TCP"
  vpc_id   = data.aws_vpc.selected.id
  target_type  = "ip"

  tags = {
    Name = "grafana-tg"
  }
}
resource "aws_lb_target_group_attachment" "grafana-ip" {
  target_group_arn = aws_lb_target_group.grafana.arn
  target_id        = "10.0.0.66"  # Register the specific IP address
  port             = 3000
}

resource "aws_lb_listener" "grafana" {
  load_balancer_arn = aws_lb.nlb.arn
  port              = 80
  protocol          = "TCP"

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.grafana.arn
  }
}

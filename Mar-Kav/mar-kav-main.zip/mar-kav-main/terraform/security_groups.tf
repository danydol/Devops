resource "aws_security_group" "ecs" {
  vpc_id = data.aws_vpc.selected.id

  ingress {
    from_port   = 3000
    to_port     = 3000
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
  tags = {
    Name = "ecs_sg01"
  }
}
resource "aws_security_group" "loki" {
  name   = "loki-sg"
  vpc_id = var.vpc_id

  ingress {
    from_port   = 3100 
    to_port     = 3100
    protocol    = "tcp"
    security_groups = [aws_security_group.ecs.id]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
  
}


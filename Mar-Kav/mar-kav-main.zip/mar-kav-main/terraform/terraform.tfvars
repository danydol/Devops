vpc_id = "vpc-0d73e54fc97507c02"

private_subnet_ids = [
  "subnet-09223fee8000f1aee",
  "subnet-05bcc0b14e2784890",
  "subnet-0e8fdbb7e35b63327"
]

public_subnet_ids = [
  "subnet-0741a255b00f24b5b",
  "subnet-0a228680c0ed298e3",
  "subnet-081eef07de6f72a16"
]


  


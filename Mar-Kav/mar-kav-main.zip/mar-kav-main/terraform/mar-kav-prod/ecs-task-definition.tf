resource "aws_ecs_task_definition" "mk-prod-django" {
  family                   = "mk-prod-django"
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = "256"
  memory                   = "512"
  task_role_arn            = aws_iam_role.ecs_task_role.arn
  execution_role_arn = aws_iam_role.ecs_task_execution.arn
container_definitions = jsonencode([
  {
    name      = "django"
    image     = "471112838468.dkr.ecr.il-central-1.amazonaws.com/mk-prod/django:latest"
    essential = true
    portMappings = [
      {
        containerPort = 80
        hostPort      = 80
        protocol      = "tcp"
      }
    ]
   }
 ])
}

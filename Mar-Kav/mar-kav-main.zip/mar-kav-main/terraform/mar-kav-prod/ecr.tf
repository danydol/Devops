resource "aws_ecr_repository" "mk-prod" {
  name = "mk-prod/django"

  image_tag_mutability = "MUTABLE"

  image_scanning_configuration {
    scan_on_push = true
  }

  tags = {
    Environment = "Prod"
    Name        = "mk-prod/django"
  }
}

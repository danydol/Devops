resource "aws_lb" "ecs-alb" {
  name               = "ecs-alb"
  internal           = true
  load_balancer_type = "application"
  security_groups    = [aws_security_group.ecs-access.id]
  subnets            = ["subnet-07b08e8f3cf53e8e7", "subnet-03cd2fed45791f4fa"]

  tags = {
    Name = "ecs-nlb"
  }
}

resource "aws_lb_target_group" "django-tg" {
  name     = "django-tg"
  port     = 80
  protocol = "HTTP"
  vpc_id   = "vpc-01d5184817f0eb305"
  target_type  = "ip"

  tags = {
    Name = "django-tg"
  }
}
resource "aws_lb_target_group_attachment" "django-ip" {
  target_group_arn = aws_lb_target_group.django-tg.arn
  target_id        = "10.113.66.22"  # Register the specific IP address
  port             = 80
}

resource "aws_lb_listener" "django" {
  load_balancer_arn = aws_lb.ecs-alb.arn
  port              = 80
  protocol          = "HTTP"

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.django-tg.arn
  }
}

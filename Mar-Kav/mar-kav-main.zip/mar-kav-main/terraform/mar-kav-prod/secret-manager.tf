# Create the secret metadata (name, description, etc.)
resource "aws_secretsmanager_secret" "mk-prod-db-secret" {
  name        = "mk-prod-db-secret"
  description = "Secret for db"
}

# Add the actual secret value
resource "aws_secretsmanager_secret_version" "mk-prod-version" {
  secret_id     = aws_secretsmanager_secret.mk-prod-db-secret.id
  secret_string = file("secret-manager.json")
  }


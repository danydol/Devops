resource "aws_ecs_cluster" "mk-prod-cluster" {
  name = "mk-prod-cluster"

   setting {
    name  = "containerInsights"
    value = "enabled"
  }

   setting {
    name  = "containerInsights"
    value = "enabled"
  }

  tags = {
    Name = "mk-prod-cluster"
  }
}

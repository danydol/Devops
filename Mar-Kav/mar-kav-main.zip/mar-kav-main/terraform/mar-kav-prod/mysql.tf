
# Create a security group for RDS access
resource "aws_security_group" "Mysql-SG" {
  name        = "Mysql-SG"
  description = "Allow MySQL inbound traffic"
  vpc_id      = "vpc-01d5184817f0eb305"  # Replace with your VPC ID

  ingress {
    from_port   = 3306
    to_port     = 3306
    protocol    = "tcp"
    cidr_blocks = ["10.113.64.0/19"] 
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

# Load credentials from external JSON
locals {
  db_creds = jsondecode(file("db-credentilas.json"))
}

# Assume these subnets already exist in your VPC
resource "aws_db_subnet_group" "rds_subnet_group" {
  name       = "mk-prod-subnet-group"
  subnet_ids = ["subnet-0bfd2abbf8b82b392", "subnet-0e5cf25fdb4c9f449"]  # Replace with actual subnet IDs
  tags = {
    Name = "mk-prod-subnet-group"
  }
}

# Create the MySQL RDS instance
resource "aws_db_instance" "Mysql-Instance" {
  identifier         = "db-mk-prod"
  engine             = "mysql"
  engine_version     = "8.0.40"
  instance_class     = "db.m5.large"
  allocated_storage  = 200
  username           = local.db_creds.username
  password           = local.db_creds.password
  db_name            = "mkprod"
  db_subnet_group_name    = aws_db_subnet_group.rds_subnet_group.name  # attach subnet group
  publicly_accessible = false
  skip_final_snapshot = true
  vpc_security_group_ids = [aws_security_group.Mysql-SG.id]
}



resource "aws_ecs_service" "django-service" {
  name                               = "django-service"
  cluster                            = aws_ecs_cluster.mk-prod-cluster.id
  task_definition                    = aws_ecs_task_definition.mk-prod-django.arn
  desired_count                      = 1
  launch_type                        = "FARGATE"
  enable_execute_command             = true


  network_configuration {
    subnets         = ["subnet-0e5a3b4cb42c697d5", "subnet-00599ae2e602155d5"]
    security_groups = [aws_security_group.ecs-access.id]
    assign_public_ip = false
  }

  load_balancer {
    target_group_arn = aws_lb_target_group.django-tg.arn
    container_name   = "django"
    container_port   = 80
  }

  tags = {
    Name = "django-service"
  }
}





resource "aws_route_table" "RTB-mk-prod-Private" {
  vpc_id = aws_vpc.main.id

tags = {
    Name = "RTB-mk-prod-Private"
   }
}

resource "aws_route_table_association" "subnets-mk-prod-private-az1" {
  subnet_id      = "subnet-0e5a3b4cb42c697d5"
  route_table_id = aws_route_table.RTB-mk-prod-Private.id
}


resource "aws_route_table_association" "subnet-mk-prod-private-az2" {
  subnet_id    = "subnet-00599ae2e602155d5"
  route_table_id = aws_route_table.RTB-mk-prod-Private.id
}




resource "aws_route_table" "RTB-mk-prod-Public" {
  vpc_id = aws_vpc.main.id

tags = {
    Name = "RTB-mk-prod-Public"
   }
}

resource "aws_route_table_association" "subnet-mk-prod-public-az1" {
  subnet_id    = "subnet-07b08e8f3cf53e8e7"
  route_table_id = aws_route_table.RTB-mk-prod-Public.id
}


resource "aws_route_table_association" "subnet-mk-prod-public-az2" {
  subnet_id    = "subnet-03cd2fed45791f4fa"
  route_table_id = aws_route_table.RTB-mk-prod-Public.id
}


resource "aws_route_table" "RTB-mk-prod-TGWA" {
  vpc_id = aws_vpc.main.id

tags = {
    Name = "RTB-mk-prod-TGWA"
   }
}

resource "aws_route_table_association" "subnet-mk-prod-tgwa-az1" {
  subnet_id    = "subnet-0d43772d5292a0182"
  route_table_id = aws_route_table.RTB-mk-prod-TGWA.id
}


resource "aws_route_table_association" "subnet-mk-prod-tgwa-az2" {
  subnet_id    = "subnet-00009b059a46a107d"
  route_table_id = aws_route_table.RTB-mk-prod-TGWA.id
}

resource "aws_route_table" "RTB-mk-prod-rds" {
  vpc_id = aws_vpc.main.id

tags = {
    Name = "RTB-mk-prod-rds"
   }
}

resource "aws_route_table_association" "subnet-mk-prod-rds-az1" {
  subnet_id    = "subnet-0bfd2abbf8b82b392"
  route_table_id = aws_route_table.RTB-mk-prod-rds.id
}


resource "aws_route_table_association" "subnet-mk-prod-rds-az2" {
  subnet_id    = "subnet-0e5cf25fdb4c9f449"
  route_table_id = aws_route_table.RTB-mk-prod-rds.id
}

resource "aws_ecs_service" "grafana" {
  name                               = "grafana-service"
  cluster                            = aws_ecs_cluster.main.id
  task_definition                    = aws_ecs_task_definition.grafana.arn
  desired_count                      = 1
  launch_type                        = "FARGATE"
  enable_execute_command             = true

  network_configuration {
    subnets         = var.private_subnet_ids
    security_groups = [aws_security_group.ecs.id]
    assign_public_ip = false
  }

  load_balancer {
    target_group_arn = aws_lb_target_group.grafana.arn
    container_name   = "grafana"
    container_port   = 3000
  }

  tags = {
    Name = "grafana-service"
  }
}

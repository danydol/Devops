from django.shortcuts import render
from django.http import JsonResponse
from django.http import HttpResponse
from django.template import loader
import codecs
import json
import pandas as pd
import csv


from .models import GraphData

# Create your views here.
############################################################################
def GraphData_csv_view(request):

    q_dict = request.GET
    debug_message = None
    id = None
    ind = None
    type = None

    # http://127.0.0.1:8000/graphdataDL?ind=LD&id=10234-2&ty=RR

    try:
        ind = q_dict.get('ind')
        id = q_dict.get('id')
        type = q_dict.get('ty')
    except:
        debug_message = 'חיפוש לא חוקי'
        id = None

    dg_objs = None

    # try to load
    if id is not None:
        try:
            print(id)

            dg_objs = GraphData.objects.filter(Index_Id=id, Type = type, Index = ind)

        except GraphData.DoesNotExist:
            dg_objs = None
            debug_message = 'GraphData.DoesNotExist'
    else:
        debug_message = 'No ts_Ids'

    if dg_objs == None:
        debug_message = 'No Route_Full_Ids Found'

    Data = pd.DataFrame()

    if type == 'RR':

        # concat objects
        for dg in dg_objs:
            json_object = json.loads(dg.Data)
            df = pd.DataFrame(json_object['Data'])
            Data = pd.concat([Data, df])

        # rename for download
        Data = Data[['PlannedTripStartTime', 'Weekday', 'NumOfPassengers_Top80p']] # 'numOfRides', 'Sample', 'AVG_NumOfPassengers',
        Data.rename(columns = {'NumOfPassengers_Top80p':'EstimatedNumOfPassengers', }, inplace = True)
    
    elif type == 'LP':
        # concat objects
        for dg in dg_objs:
            json_object = json.loads(dg.Data)
            df = pd.DataFrame(json_object['Data'])
            df['StopOrder'] = df.index
            df['Section'] = dg.Section_2

            # UpPercent	DownPercent	ContinuePercent
            # maxRiders = max(json_object['TripUpEightiethPercentile'],
            #                 json_object['TripDownEightiethPercentile'],
            #                 json_object['TripTikufimEightiethPercentile'])

            maxRiders = json_object['TripTikufimEightiethPercentile']                            
 
            df['Up'] = df['UpPercent'] * maxRiders # json_object['TripUpEightiethPercentile']
            df['Down'] = df['DownPercent'] * maxRiders # json_object['TripUpEightiethPercentile']
            df['Continue'] = df['ContinuePercent'] * maxRiders # json_object['TripUpEightiethPercentile']

            Data = pd.concat([Data, df])

        # prep for download
        Data = Data[['Section', 'StopOrder', 'StopCode', 'StopName', 'Up', 'Down', 'Continue']]
        Data[[ 'Up', 'Down', 'Continue']] = Data[[ 'Up', 'Down', 'Continue']].round(1)

    # Download file name
    filename = 'graphdata_Line_' + id + '_' + ind + '_' + type + '.csv'

    # Create the HttpResponse object with the appropriate CSV header.
    response = HttpResponse(
        content_type='text/csv; charset=utf-8',
        headers={'Content-Disposition': 'attachment; filename="' + filename +'"'},
    )

    response.write(codecs.BOM_UTF8)

    Data.to_csv(path_or_buf=response, encoding='utf-8-sig', index=False) 

    return response

################################### 
def GraphData_html_view(request):

    q_dict = request.GET
    # print('q_dict', q_dict)

    debug_message = None
    id = None
    titles = None
    tableData = None
    debug_message = None

    # http://127.0.0.1:8000/graphdata?ind=LD&id=10234-2&ty=RR&sc=WD

    try:
        ind = q_dict.get('ind')
        id = q_dict.get('id')
        type = q_dict.get('ty')
        section = q_dict.get('sc')
        section2 = q_dict.get('sc2') # we use ID here - PK - primery key
    except:
        debug_message = 'חיפוש לא חוקי'
        id = None

    dg_objs = None

    # if section2 is None:
    #     section2 = ''

    # try to load
    if id is not None:
        try:

            if section2 is None:
                dg_objs = GraphData.objects.get(Index = ind, Index_Id=id, Type = type, Section = section, Section_2 = section2)
            else:
                dg_objs = GraphData.objects.get(pk = section2)

        except GraphData.DoesNotExist:
            dg_objs = None
            debug_message = 'GraphData.DoesNotExist'
    else:
        debug_message = 'No ts_Ids'

    if dg_objs == None:
        debug_message = 'No dg_objs Found'

    else:

        json_object = json.loads(dg_objs.Data)

        Data = pd.DataFrame(json_object['Data'])
        Data['color'] = ''

        if type == 'RR':
            Data.rename(columns = {'PlannedTripStartTime':'key', 
                                'NumOfPassengers_Top80p':'value'}, inplace = True)
            titles = {  'key': 'שעה', 
                        'value':'נוסעים', 
                        'bar': ''}
            
        elif type == 'LP':

            # UpPercent	DownPercent	ContinuePercent
            # maxRiders = max(json_object['TripUpEightiethPercentile'],
            #                 json_object['TripDownEightiethPercentile'],
            #                 json_object['TripTikufimEightiethPercentile'])
            maxRiders = json_object['TripTikufimEightiethPercentile']

            # factor = json_object['TripUpEightiethPercentile']
            Data['passengers'] = round(Data['ContinuePercent'] * maxRiders ,1)
            
            Data.rename(columns = {'StopName':'key', 
                                'passengers':'value'}, inplace = True)
            titles = {  'key': 'תחנה', 
                        'value':'נוסעים ממשיכים',
                        'bar': ''}
            
            BusSize = json_object['BusSize']

            # Color if too hight
            Data.loc[Data['value'] > BusSize, 'color'] = 't_red'
            

        GraphMax = Data['value'].max()
        if GraphMax < 30:
            GraphMax = 30
            
        Data['bar'] = 100 - round(100*(Data['value']/GraphMax), 1)
        Data['bar'] = Data['bar'].fillna(100)
        Data['bar'] = Data['bar'].astype(str) + '%'

        tableData = Data[['key', 'value', 'bar', 'color']].to_dict('index')

    # save to context
    view_context = {
        'type': type,
        'titles' : titles,
        'tableData': tableData,
        'debug_message' : debug_message,
    }

    return render(request, 'apps/graph.html', context=view_context)
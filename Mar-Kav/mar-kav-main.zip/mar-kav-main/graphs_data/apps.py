from django.apps import AppConfig


class GraphsDataConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'graphs_data'

from django.db import models

from django.core.validators import MaxValueValidator, MinValueValidator
from django.utils.translation import gettext_lazy as _

# Create your models here.
class GraphData(models.Model):

    # מה מודדים?
    class data_types(models.TextChoices):
        RIDERS = 'RR', _('הערכת נוסעים') # הערכת מספר נוסעים
        TICKETS = 'TC', _('עליות נוסע') # עליות נוסע - כרטוסים
        PROFILE = 'LP', _('פרופיל קו') # פרופיל קו על פי תחנות

    Type = models.CharField(
        max_length=2,
        choices=data_types.choices,
        default=data_types.RIDERS,
    )

    # באיזה פילוח ?
    class section_types(models.TextChoices):
        SUNDAY = 'D1', _('ראשון')
        MONDAY = 'D2', _('שני')
        TUESDAY = 'D3', _('שלישי')
        WEDNSDAY = 'D4', _('רביעי')
        THURSDAY = 'D5', _('חמישי')
        FRIDAY = 'D6', _('שישי')
        SATERDAY = 'D7', _('שבת')
        WORKDAY = 'WD', _('יום חול')
        WEEDDAY = 'WE', _('שבועי')

    Section = models.CharField(
        max_length=2,
        choices=section_types.choices,
        default=section_types.WORKDAY,
    )

    Section_2 = models.CharField(max_length=50, null=True, blank=True, default=None) # פילוח נוסף לגרפים שצריכים עוד רמה

    # למי משייכים?
    class index_types(models.TextChoices):
        LINE = 'LI', _('Line') # לקו
        LINEDIR = 'LD', _('Line-Direction') # לקו - כיוון
        LINEDIRALT = 'LA', _('Line-Direction-Alternative') # מקט - כיוון - חלופה
        STATION = 'ST', _('Station') # לתחנה
        SETTLEMENT = 'CT', _('Settlement') # לישוב

    Index = models.CharField(
        max_length=2,
        choices=index_types.choices,
        default=index_types.LINEDIR,
    )

    Index_Id = models.CharField(db_index=True, max_length=50) # האינדקס של האובייקט אליו משייכים את הדאטה


    Data = models.TextField()
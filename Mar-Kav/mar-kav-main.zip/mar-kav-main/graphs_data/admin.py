from django.contrib import admin

# Register your models here.
from .models import GraphData

class PageAdmin(admin.ModelAdmin):
    list_display = ['Type', 'Section', 'Index', 'Index_Id']
    search_fields = ['Index_Id']

admin.site.register(GraphData, PageAdmin)
from django.contrib import admin

# Register your models here.
from .models import StationRidership

class StationRidershipAdmin(admin.ModelAdmin):
    list_display = ['id', 'Route_Id', 'Route_LineDirection_Id', 'Stop_ID', 'Attributes']
    search_fields = ['Route_LineDirection_Id', 'Stop_ID', 'Attributes']

admin.site.register(StationRidership, StationRidershipAdmin)
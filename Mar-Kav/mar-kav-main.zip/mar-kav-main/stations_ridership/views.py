from django.shortcuts import render
from django.db.models import Max
import pandas as pd
from django.views.decorators.clickjacking import xframe_options_exempt

from django.http import JsonResponse
from django.http import HttpResponse
from django.template import loader
import codecs
import csv

# Create your views here.
from .models import StationRidership
from shapes.models import Shape
from lines.models import Line

def stop_sitemap_view(request):

    # try:
    #     n = int(request.GET.get('n'))
    # except:
    #     n = 1

    # stop_objs = StationRidership.objects.all()[(n-1)*10000:n*10000]
    stop_objs = StationRidership.objects.order_by().values('Stop_ID').distinct()
    # save to context
    view_context = {
        'stop_list': stop_objs,
    }

    view_context.update(Line.objects.aggregate(Max('Ridership_Updated_on')))
    # {'Ridership_Updated_on__max': the max date}

    return render(request, 'apps/sitemap_stops.xml', context=view_context)

#######################################     ##########
@xframe_options_exempt
def bus_stop_view(request, stop_Id=None):

    stop_objs = None
    shape_objs = None
    debug_message = None

    # try to load
    if stop_Id is not None:
        try:
            print(stop_Id)

            stop_objs = StationRidership.objects.filter(Stop_ID=stop_Id).order_by('-Week')

            if stop_objs:
                SR_dataframe = pd.DataFrame.from_records(stop_objs.values())

                WeeklyPassengers = round(SR_dataframe['Week'].sum(),1)

                PivData = SR_dataframe.pivot_table(index=['Route_Id'],
                                            values=['Week'],
                                            aggfunc=sum)

                lines_data = pd.DataFrame(PivData.to_records())
                lines_data['Week'] = round(lines_data['Week'],1)

                Route_Full_Id_list = SR_dataframe['Route_Full_Id'].unique().tolist()
                shape_objs = Shape.objects.filter(Route_Full_Id__in=Route_Full_Id_list)

                Route_Id_list = SR_dataframe['Route_Id'].unique().tolist()
                line_objs = Line.objects.filter(Route_Id__in=Route_Id_list)

                Lines_dataframe = pd.DataFrame.from_records(line_objs.values())

                Lines_dataframe = Lines_dataframe.merge(lines_data, how='left',on='Route_Id')

                Lines_dataframe.sort_values('Week', inplace=True, ascending=False)
                Lines_dataframe['WeekPR'] = round(100*Lines_dataframe['Week'] / Lines_dataframe['Week'].sum(),1)

        except StationRidership.DoesNotExist:
            stop_objs = None
            debug_message = 'StationRidership.DoesNotExist'
    else:
        debug_message = ' No stop_Id'

    if not stop_objs:
        debug_message = 'No bus station Found'

    Stop_obj = {
        'Stop_ID' : stop_objs[0].Stop_ID,
        'Stop_name': stop_objs[0].Stop_name,
        'Lat': stop_objs[0].Lat,
        'Long': stop_objs[0].Long,
        'WeeklyPass' : WeeklyPassengers,
    }

    view_context = {
        'line_objs': Lines_dataframe,
        'Stop_obj' : Stop_obj,
        'Stop_objs' : stop_objs,
        'shape_objs' : shape_objs,
        'debug_message' : debug_message,
    }

    print(debug_message)

    # http://127.0.0.1:8000/stop/61298/
    return render(request, 'apps/stop_map_detail.html', context=view_context)

#################################### VVVVVV#####################
def LineStationsRidership_csvDownload_view(request):

    q_dict = request.GET
    ts_objs = None

    try:
        ts_Id = q_dict.get('q')
    except:
        debug_message = 'חיפוש לא חוקי'
        ts_Id = None

    # try to load
    print('ts_Id ',ts_Id)
    if ts_Id is not None:
        try:
            ts_objs = StationRidership.objects.filter(Route_Full_Id=ts_Id).order_by('Stop_line_order')

        except StationRidership.DoesNotExist:
            ts_objs = None
            debug_message = 'StationRidership.DoesNotExist'
            print('StationRidership.DoesNotExist')
    else:
        debug_message = 'No ts_Ids'

    filename = 'StationsRidership_Line_' + ts_Id + '.csv'

    # http://127.0.0.1:8000/stridershipDL/?q=21015

    # Create the HttpResponse object with the appropriate CSV header.
    response = HttpResponse(
        content_type='text/csv',
        headers={'Content-Disposition': 'attachment; filename="' + filename +'"'},
    )

    response.write(codecs.BOM_UTF8)
    writer = csv.writer(response)

    writer.writerow(['מקט-כיוון','תחנה','שם תחנה','סידורי תחנה',
                     'ממוצע יום א','ממוצע יום ב','ממוצע יום ג','ממוצע יום ד','ממוצע יום ה','ממוצע יום ו','ממוצע יום שבת', 'ממוצע שבועי',
                     'הערות'])

    if ts_objs is not None:
        ts_fields = ts_objs.values_list('Route_LineDirection_Id', 'Stop_ID', 'Stop_name', 'Stop_line_order',
                                        'Day_1','Day_2','Day_3','Day_4','Day_5','Day_6','Day_7', 'Week',
                                        'Attributes',)
        for ts in ts_fields:
            writer.writerow(ts)

    return response

####################  ^^^^^^^^^^^^^^^^^ ##########

#######################################################################
def StationRidership_csvDownload_view(request):

    q_dict = request.GET
    stop_Id = None

    try:
        stop_Id = q_dict.get('q')
    except:
        debug_message = 'חיפוש לא חוקי'
        stop_Id = None

    # try to load
    print('stop_Id ',stop_Id)
    if stop_Id is not None:
        try:
            # ts_objs = StationRidership.objects.filter(Route_Full_Id=ts_Id).order_by('Stop_line_order')
            stop_objs = StationRidership.objects.filter(Stop_ID=stop_Id).order_by('-Week')

        except StationRidership.DoesNotExist:
            stop_Id = None
            debug_message = 'StationRidership.DoesNotExist'
            print('StationRidership.DoesNotExist')
    else:
        debug_message = 'No ts_Ids'

    filename = 'StationRidership_Stop_' + stop_Id + '.csv'

    # http://127.0.0.1:8000/stridershipDL/?q=21015

    # Create the HttpResponse object with the appropriate CSV header.
    response = HttpResponse(
        content_type='text/csv',
        headers={'Content-Disposition': 'attachment; filename="' + filename +'"'},
    )

    response.write(codecs.BOM_UTF8)
    writer = csv.writer(response)

    writer.writerow(['מקט-כיוון','תחנה','שם תחנה','סידורי תחנה',
                     'ממוצע יום א','ממוצע יום ב','ממוצע יום ג','ממוצע יום ד','ממוצע יום ה','ממוצע יום ו','ממוצע יום שבת', 'ממוצע שבועי',
                     'הערות'])

    if stop_objs is not None:
        ts_fields = stop_objs.values_list('Route_LineDirection_Id', 'Stop_ID', 'Stop_name', 'Stop_line_order',
                                        'Day_1','Day_2','Day_3','Day_4','Day_5','Day_6','Day_7', 'Week',
                                        'Attributes',)
        for ts in ts_fields:
            writer.writerow(ts)

    return response


############################################################################
def StationRidership_json_view(request):

    q_dict = request.GET
    debug_message = None
    ld_Ids = None

    try:
        ld_Id = q_dict.get('ld')
        day = q_dict.get('dt')
    except:
        debug_message = 'חיפוש לא חוקי'
        ld_Id = None

    SR_objs = None

    # try to load
    if ld_Id is not None:
        try:
            print(ld_Id)

            SR_objs = StationRidership.objects.filter(Route_Full_Id=ld_Id).order_by('Stop_line_order')

        except StationRidership.DoesNotExist:
            SR_objs = None
            debug_message = 'StationRidership.DoesNotExist'
    else:
        debug_message = 'No ld_Id'

    if SR_objs == None:
        debug_message = 'No Route_LineDirection_Id Found'

    print('debug_message',debug_message)

    # collect the data
    cols = [{'id':'A','label':'Stop Name','pattern':'','type':'string'},{'id':'A','label':'עולים בתחנה','pattern':'','type':'number'}]

    rows = []

    for SR_obj in SR_objs:
        # if day == 'D1':
        #     val = SR_obj.Day_1
        # elif day == 'D2':
        #     val = SR_obj.Day_2
        # elif day == 'D3':
        #     val = SR_obj.Day_3
        # elif day == 'D4':
        #     val = SR_obj.Day_4
        # elif day == 'D5':
        #     val = SR_obj.Day_5
        # elif day == 'D6':
        #     val = SR_obj.Day_6
        # elif day == 'D7':
        #     val = SR_obj.Day_7
        # else:
        #     val = 0

        single_r_v = [{'v':str(SR_obj.Stop_name)}, {'v':SR_obj.Week}]
        single_r = {'c': single_r_v}

        rows.append(single_r)

    # save to context
    jsonData = {"cols": cols, "rows": rows}

    return JsonResponse(jsonData, json_dumps_params={'ensure_ascii': False})
    # return render(request, 'apps/timeseries.html', jsonData_c=jsonData)

#################################################################
def station_geojson_view(request):

    q_dict = request.GET
    debug_message = None
    ld_Ids = None

    try:
        ld_Id = q_dict.get('ld')
        day = q_dict.get('dt')
    except:
        debug_message = 'חיפוש לא חוקי'
        ld_Id = None

    SR_objs = None

    # try to load
    if ld_Id is not None:
        try:
            print(ld_Id)

            SR_objs = StationRidership.objects.filter(Route_Full_Id=ld_Id).order_by('Stop_line_order')

        except StationRidership.DoesNotExist:
            SR_objs = None
            debug_message = 'StationRidership.DoesNotExist'
    else:
        debug_message = 'No ld_Id'

    if SR_objs == None:
        debug_message = 'No Route_LineDirection_Id Found'

    print('debug_message',debug_message)


    SR_dataframe = pd.DataFrame.from_records(SR_objs.values())

    SR_dataframe['Size'] = round(5 + 10 * SR_dataframe['Week'] / SR_dataframe['Week'].max(),0)
    SR_dataframe['Week'] = round(SR_dataframe['Week'],1)

    # save to context
    view_context = {
        'stations_objs': SR_dataframe,
        'route_id' : ld_Id,
        'debug_message' : debug_message,
    }

    print('stations_geojson_view OK')

    # return JsonResponse({'foo':'bar'})
    # return render(request, 'apps/stations_geojson.geojson', context=view_context)

    response = render(request, 'apps/stations_geojson.geojson', context=view_context)
    response['X-Robots-Tag'] = 'noindex'
    return response

from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator

# Create your models here.
class StationRidership(models.Model):

    Route_Id = models.PositiveIntegerField(db_index=True, validators=[MinValueValidator(10000),
                                                         MaxValueValidator(100000)]) # מק"ט
    Route_LineDirection_Id = models.CharField(max_length=10, default=None) # מקט - כיוון
    Route_Full_Id = models.CharField(db_index=True, max_length=12, default=None) # מקט - כיוון - חלופה

    Stop_name = models.CharField(max_length=100, default=None) # שם תחנה
    Stop_ID = models.PositiveIntegerField(validators=[MinValueValidator(1),
                                    MaxValueValidator(99999)]) # מקט תחנה
    Stop_line_order = models.PositiveIntegerField(validators=[MinValueValidator(1),
                                    MaxValueValidator(250)]) # סידורי תחנה

    Lat = models.FloatField() # קואורדינטות
    Long = models.FloatField() # קואורדינטות

    Day_1 = models.FloatField(validators=[MinValueValidator(0)]) # ממוצע עולים בתחנה ביום זה
    Day_2 = models.FloatField(validators=[MinValueValidator(0)]) # ממוצע עולים בתחנה ביום זה
    Day_3 = models.FloatField(validators=[MinValueValidator(0)]) # ממוצע עולים בתחנה ביום זה
    Day_4 = models.FloatField(validators=[MinValueValidator(0)]) # ממוצע עולים בתחנה ביום זה
    Day_5 = models.FloatField(validators=[MinValueValidator(0)]) # ממוצע עולים בתחנה ביום זה
    Day_6 = models.FloatField(validators=[MinValueValidator(0)]) # ממוצע עולים בתחנה ביום זה
    Day_7 = models.FloatField(validators=[MinValueValidator(0)]) # ממוצע עולים בתחנה ביום זה
    Week = models.FloatField(validators=[MinValueValidator(0)]) # ממוצע עולים בתחנה במהלך שבוע שלם

    Attributes = models.CharField(max_length=250, default=None) # מאפיינים לתחנה זו בקו זה


from django.contrib import admin

# Register your models here.
from .models import Comment

class CommentAdmin(admin.ModelAdmin):
    list_display = ['Route_Id', 'date', 'Type', 'Priority' ,'Title']
    search_fields = ['Route_Id', 'Title']

admin.site.register(Comment, CommentAdmin)
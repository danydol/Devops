from django import forms
from .models import Comment

class AddCommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ['Route_Id', 'Type', 'Priority' ,'Content', 'Author']
        labels = {
            'Priority': _('עדיפות'),
            'Content': _('תוכן'),
        }
        help_texts = {
            'Priority': _('Some useful help text.'),
        }
        error_messages = {
            'Content': {
                'max_length': _("This writer's name is too long."),
            },
        }
        widgets = {
            'Route_Id': forms.HiddenInput(),
            'Type': forms.HiddenInput(),
            'Author': forms.HiddenInput(),
        },
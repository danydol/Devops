from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator
from django.utils.translation import gettext_lazy as _
from django.contrib.auth.models import User

# Create your models here.
class Comment(models.Model):
    Route_Full_Id = models.CharField(max_length=12, null=True, blank=True) # מקט - כיוון - חלופה
    Route_LineDirection_Id = models.CharField(max_length=10, null=True, blank=True) # מקט - כיוון
    Route_Id = models.PositiveIntegerField(validators=[MinValueValidator(10000),
                                                         MaxValueValidator(100000)]) # מק"ט

    class m_types(models.TextChoices):
        NOTICE = 'NO', _('הודעה')
        COMMENT = 'CO', _('הערה')
        OBSERVATION = 'OB', _('אבחנה')
        MENTION = 'ME', _('תזכור')

    Type = models.CharField(
        max_length=2,
        choices=m_types.choices,
        default=m_types.COMMENT,
    )

    class m_priority(models.IntegerChoices):
        VERY_HIGH   = 5, _('גבוהה ביותר')
        HIGH        = 4, _('גבוהה')
        MEDIUM      = 3, _('בינונית')
        LOW         = 2, _('נמוכה')
        NOTE        = 1, _('לידיעה בלבד')

    Priority = models.IntegerField(
        choices=m_priority.choices,
        default=m_priority.NOTE,
    )

    Title = models.CharField(max_length=150, null=True, blank=True)
    Content = models.TextField()
    Author = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL)

    date = models.DateTimeField(auto_now_add=True, blank=True)


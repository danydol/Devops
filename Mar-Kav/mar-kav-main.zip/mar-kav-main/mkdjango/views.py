#my file

from django.http import HttpResponse
from django.http import JsonResponse
from django.shortcuts import render
from pages.models import Page

#import os

def home_view(request):

    # HTML_STRING = """
    # <h1>this is my page after git</h1>
    # """

    #osPath = os.path.abspath(__file__)

    #HTML_STRING += osPath

    page_obj = Page.objects.get(id=1)

    # save to context
    view_context = {
        'disable_search_nav' : True,
        'page_data' : page_obj,
        # 'debug_message': 'Under construction',
    }

    return render(request, 'apps/home.html', context=view_context)

def health_check(request):
    return JsonResponse({'status': 'ok'})

def april1st_view(request):
    HTML_STRING = """
            """

    return HttpResponse(HTML_STRING)


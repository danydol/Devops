"""mkdjango URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path

from lines.views import (
    line_list_view,
    lines_serch_view,
#    line_detail_view,
    line_map_view,
    line_sitemap_view,
    LineRidershipHistory_csvDownload_view,
)
from ridership.views import (
    ridership_detail_view,
    lineDirection_view,
)
from accounts.views import (
    login_view,
    logout_view,
    register_view,
)
from shapes.views import (
    shapes_geojson_view,
)
from pages.views import (
    page_detail_view,
)
from time_series.views import (
    timeseries_json_view,
    timeseries_csvDownload_view,
)
from graphs_data.views import (
    GraphData_html_view,
    GraphData_csv_view,
)
from stations_ridership.views import (
    StationRidership_json_view,
    StationRidership_csvDownload_view,
    LineStationsRidership_csvDownload_view,
    station_geojson_view,
    bus_stop_view,
    stop_sitemap_view,
)


from .views import (
    home_view,
    health_check,
)

urlpatterns = [

    path('', home_view),
    path('lines', line_list_view),
    path('lines_q', lines_serch_view),
    path('line/sitemap.xml', line_sitemap_view),
    path('line/map/<str:Route_Id>/', line_map_view),
#    path('line_D/<int:id>/', line_detail_view),
    path('line/<str:Route_Id>/', ridership_detail_view),
    path('line/<str:Route_Id>/<str:Direction>/', lineDirection_view),
    path('RidershipHistoryDL/', LineRidershipHistory_csvDownload_view),
    path('login/', login_view),
    path('logout/', logout_view),
    path('page/<int:id>/', page_detail_view),
    path('shapes/', shapes_geojson_view),
    path('timeseries/', timeseries_json_view),
    path('timeseriesDL/', timeseries_csvDownload_view),
    path('stridership/', StationRidership_json_view),
    path('stridershipDL/', LineStationsRidership_csvDownload_view),
    path('stopridershipDL/', StationRidership_csvDownload_view),
    path('stopGJ/', station_geojson_view),
    path('stop/<str:stop_Id>/', bus_stop_view),
    path('stop/sitemap.xml', stop_sitemap_view),
    path('graphdata/', GraphData_html_view),
    path('graphdataDL/', GraphData_csv_view),

    path('admin/', admin.site.urls),
    path('healthz/', health_check),
]

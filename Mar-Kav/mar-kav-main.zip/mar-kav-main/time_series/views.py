from django.shortcuts import render
from django.http import JsonResponse
from django.http import HttpResponse
from django.template import loader
import codecs

# Create your views here.
from .models import TimeSeries


def timeseries_csvDownload_view(request):

    q_dict = request.GET

    try:
        ts_Id = q_dict.get('q')
    except:
        debug_message = 'חיפוש לא חוקי'
        ts_Id = None

    # try to load
    print('ts_Id ',ts_Id)
    if ts_Id is not None:
        try:
            ts_objs = TimeSeries.objects.filter(Index_Id__startswith=ts_Id)

        except TimeSeries.DoesNotExist:
            ts_objs = None
            debug_message = 'TimeSeries.DoesNotExist'
    else:
        debug_message = 'No ts_Ids'

    filename = 'timeline_' + ts_Id + '.csv'

    # http://127.0.0.1:8000/timeseriesDL?q=21015

    # Create the HttpResponse object with the appropriate CSV header.
    response = HttpResponse(
        content_type='text/csv',
        headers={'Content-Disposition': 'attachment; filename="' + filename +'"'},
    )

    response.write(codecs.BOM_UTF8)

    t = loader.get_template('apps/ts_csv.txt')
    c = {'ts_objs': ts_objs}
    response.write(t.render(c))

    return response

############################################################################
def timeseries_json_view(request):

    q_dict = request.GET
    debug_message = None
    ts_Ids = None

    try:
        ts_Ids = q_dict.get('ld')
        section = q_dict.get('dt')
        type = q_dict.get('ty')
    except:
        debug_message = 'חיפוש לא חוקי'
        ts_Ids = None

    ts_objs = None

    # try to load
    if ts_Ids is not None:
        try:
            print(ts_Ids)
            ts_Ids_list = list(ts_Ids.split(","))

            ts_objs = TimeSeries.objects.filter(Index_Id__in=ts_Ids_list, Section = section, Type = type, Index = 'LD')

        except TimeSeries.DoesNotExist:
            ts_objs = None
            debug_message = 'TimeSeries.DoesNotExist'
    else:
        debug_message = 'No ts_Ids'

    if ts_objs == None:
        debug_message = 'No Route_Full_Ids Found'

    print('ts_objs', ts_objs)

    # collect the data
    cols = [{'id':'A','label':'Hour','pattern':'','type':'string'}]
    tsLists_all = []
    for ts_index, ts_o in enumerate(ts_objs): #.iterator():
        cols.append({'id':'A_' +str(ts_index),'label': ts_o.Index_Id + ' ' + ts_o.get_Section_display() ,'pattern':'','type':'number'})

        ts_list = ts_o.Observation24H.split(',')
        tsLists_all.append(ts_list)

    # flipped direction
    ts_h = list(zip(*tsLists_all))

    rows = []
    for h_index, h_row in enumerate(ts_h):
        single_r = '{"c":['
        single_r_v = [{'v':str(h_index)}]
        for cell_h in h_row:
            single_r_v.append({'v': float(cell_h) })
        single_r = {'c': single_r_v}

        rows.append(single_r)

    # save to context
    jsonData = {"cols": cols, "rows": rows}

    return JsonResponse(jsonData, json_dumps_params={'ensure_ascii': False})
    # return render(request, 'apps/timeseries.html', jsonData_c=jsonData)
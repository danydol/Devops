from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator
from django.utils.translation import gettext_lazy as _

# Create your models here.
class TimeSeries(models.Model):
    # מה מודדים?
    class data_types(models.TextChoices):
        RIDES = 'RE', _('נסיעות אוטובוס') # נסיעות
        TICKETS = 'TC', _('עליות נוסע') # עליות נוסע - כרטוסים

    Type = models.CharField(
        max_length=2,
        choices=data_types.choices,
        default=data_types.TICKETS,
    )

    # באיזה פילוח ?
    class section_types(models.TextChoices):
        SUNDAY = 'D1', _('ראשון')
        MONDAY = 'D2', _('שני')
        TUESDAY = 'D3', _('שלישי')
        WEDNSDAY = 'D4', _('רביעי')
        THURSDAY = 'D5', _('חמישי')
        FRIDAY = 'D6', _('שישי')
        SATERDAY = 'D7', _('שבת')
        WORKDAY = 'WD', _('יום חול')
        WEEDDAY = 'WE', _('שבועי')

    Section = models.CharField(
        max_length=2,
        choices=section_types.choices,
        default=section_types.WORKDAY,
    )

    # למי משייכים?
    class index_types(models.TextChoices):
        LINE = 'LI', _('Line') # לקו
        LINEDIR = 'LD', _('Line-Direction') # לקו - כיוון
        LINEDIRALT = 'LA', _('Line-Direction-Alternative') # מקט - כיוון - חלופה
        STATION = 'ST', _('Station') # לתחנה

    Index = models.CharField(
        max_length=2,
        choices=index_types.choices,
        default=index_types.LINEDIR,
    )

    Index_Id = models.CharField(max_length=15) # האינדקס של האובייקט אליו משייכים את הדאטה

    Observation24H = models.CharField(max_length=500) # טקסט המכיל ליסט של 24 ערכים, משעה 0 ועד שעה 23

# class Observation(models.Model):
#     p_TimeSeries = models.ForeignKey(TimeSeries, on_delete=models.CASCADE, related_name='TimeSeries_Observations')
#
#     # הנתונים - שעה וכמות
#     Hour = models.PositiveIntegerField(validators=[MinValueValidator(0),
#                                                          MaxValueValidator(23)]) # השעה
#
#     Amount = models.FloatField(validators=[MinValueValidator(0)], default=0) # המדידה

from django.contrib import admin

# Register your models here.
from .models import TimeSeries

class TimeSeriesAdmin(admin.ModelAdmin):
    list_display = ['Type', 'Section', 'Index', 'Index_Id']
    search_fields = ['Index_Id']

admin.site.register(TimeSeries, TimeSeriesAdmin)